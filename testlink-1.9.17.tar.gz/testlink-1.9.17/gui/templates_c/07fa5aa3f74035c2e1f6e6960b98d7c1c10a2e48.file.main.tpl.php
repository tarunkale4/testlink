<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:11
         compiled from "/development/release/latest/gui/templates/main.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20592104735ad1b05b4ee9a0-01121349%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '07fa5aa3f74035c2e1f6e6960b98d7c1c10a2e48' => 
    array (
      0 => '/development/release/latest/gui/templates/main.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20592104735ad1b05b4ee9a0-01121349',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'pageCharset' => 0,
    'tlVersion' => 0,
    'gui' => 0,
    'basehref' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b05b6d30b2_37676581',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b05b6d30b2_37676581')) {function content_5ad1b05b6d30b2_37676581($_smarty_tpl) {?>



<!DOCTYPE html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $_smarty_tpl->tpl_vars['pageCharset']->value;?>
" />
	<meta http-equiv="Content-language" content="en" />
	<meta name="generator" content="testlink" />
	<meta name="author" content="TestLink Development Team" />
	<meta name="copyright" content="TestLink Development Team" />
	<meta name="robots" content="NOFOLLOW" />
	<title>TestLink <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['tlVersion']->value, ENT_QUOTES, 'UTF-8', true);?>
</title>
	<meta name="description" content="TestLink - <?php echo (($tmp = @$_smarty_tpl->tpl_vars['gui']->value->title)===null||$tmp==='' ? "Main page" : $tmp);?>
" />
	<link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
<?php echo @constant('TL_THEME_IMG_DIR');?>
favicon.ico" type="image/x-icon" />
</head>

<frameset rows="<?php echo $_smarty_tpl->tpl_vars['gui']->value->navbar_height;?>
,*" frameborder="0" framespacing="0">
	<frame src="<?php echo $_smarty_tpl->tpl_vars['gui']->value->titleframe;?>
" name="titlebar" scrolling="no" noresize="noresize" />
	<frame src="<?php echo $_smarty_tpl->tpl_vars['gui']->value->mainframe;?>
" scrolling='auto' name='mainframe' />
	<noframes>
		<body>TestLink required a frames supporting browser.</body>
	</noframes>
</frameset>

</html>
<?php }} ?>