<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:46
         compiled from "/development/release/latest/gui/templates/inc_help.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17804889055ad1b07e7b7620-38399594%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5b6bda21b35678db9249ef0b82cca0ec02ff1afa' => 
    array (
      0 => '/development/release/latest/gui/templates/inc_help.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17804889055ad1b07e7b7620-38399594',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'inc_help_style' => 0,
    'helptopic' => 0,
    'help_text_raw' => 0,
    'help_text' => 0,
    'show_help_icon' => 0,
    'img_alt' => 0,
    'img_style' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07e82db68_25366458',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07e82db68_25366458')) {function content_5ad1b07e82db68_25366458($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_regex_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.regex_replace.php';
if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>




<?php echo lang_get_smarty(array('s'=>'help','var'=>'img_alt'),$_smarty_tpl);?>

<?php $_smarty_tpl->tpl_vars["img_style"] = new Smarty_variable((($tmp = @$_smarty_tpl->tpl_vars['inc_help_style']->value)===null||$tmp==='' ? "vertical-align: top;" : $tmp), null, 0);?>

<?php echo lang_get_smarty(array('var'=>"help_text_raw",'s'=>$_smarty_tpl->tpl_vars['helptopic']->value),$_smarty_tpl);?>

<?php $_smarty_tpl->tpl_vars["help_text"] = new Smarty_variable((($tmp = @smarty_modifier_replace(smarty_modifier_replace(smarty_modifier_regex_replace($_smarty_tpl->tpl_vars['help_text_raw']->value,"/[\r\t\n]/"," "),"'","&#39;"),"\"","&quot;"))===null||$tmp==='' ? "Help: Localization/Text is missing." : $tmp), null, 0);?>

<script type="text/javascript">
<!--
	var help_localized_text = "<img style='float: right' " +
		"src='<?php echo @constant('TL_THEME_IMG_DIR');?>
/x-icon.gif' " +
		"onclick='javascript: close_help();' /> <?php echo strtr($_smarty_tpl->tpl_vars['help_text']->value, array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
//-->
</script>  
<?php if ($_smarty_tpl->tpl_vars['show_help_icon']->value!==false){?>
<img alt="<?php echo $_smarty_tpl->tpl_vars['img_alt']->value;?>
" style="<?php echo $_smarty_tpl->tpl_vars['img_style']->value;?>
" 
	src="<?php echo @constant('TL_THEME_IMG_DIR');?>
/sym_question.gif" 
	onclick='javascript: show_help(help_localized_text);'
/>
<?php }?>
<?php }} ?>