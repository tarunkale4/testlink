<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:32
         compiled from "/development/release/latest/gui/templates/DataTables.inc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:7103611785ad1b07004d994-30618610%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c74351eb5f43d5de59346a91e7559d7189cbbca' => 
    array (
      0 => '/development/release/latest/gui/templates/DataTables.inc.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7103611785ad1b07004d994-30618610',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'basehref' => 0,
    'DataTablesOID' => 0,
    'DataTableslengthMenu' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b070082916_97813343',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b070082916_97813343')) {function content_5ad1b070082916_97813343($_smarty_tpl) {?>

<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
third_party/<?php echo @constant('TL_DATATABLES_DIR');?>
/media/css/jquery.dataTables.TestLink.css">
<script type="text/javascript" language="javascript" src="<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
third_party/<?php echo @constant('TL_DATATABLES_DIR');?>
/media/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
third_party/<?php echo @constant('TL_DATATABLES_DIR');?>
/media/js/jquery.dataTables.js"></script>

<script type="text/javascript" language="javascript" class="init">
$(document).ready(function() {
  $('#<?php echo $_smarty_tpl->tpl_vars['DataTablesOID']->value;?>
').DataTable({ "lengthMenu": [ <?php echo $_smarty_tpl->tpl_vars['DataTableslengthMenu']->value;?>
 ],stateSave: true});
} );
</script><?php }} ?>