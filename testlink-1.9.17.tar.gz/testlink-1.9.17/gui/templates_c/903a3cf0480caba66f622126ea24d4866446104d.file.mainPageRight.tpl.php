<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:41
         compiled from "/development/release/latest/gui/templates/mainPageRight.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16973469155ad1b079c61a97-22936375%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '903a3cf0480caba66f622126ea24d4866446104d' => 
    array (
      0 => '/development/release/latest/gui/templates/mainPageRight.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16973469155ad1b079c61a97-22936375',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tlCfg' => 0,
    'gui' => 0,
    'labels' => 0,
    'display_right_block_top' => 0,
    'divStyle' => 0,
    'menu_item' => 0,
    'aStyle' => 0,
    'display_right_block_1' => 0,
    'planView' => 0,
    'buildView' => 0,
    'mileView' => 0,
    'display_right_block_2' => 0,
    'lbx' => 0,
    'display_right_block_3' => 0,
    'platformAssign' => 0,
    'session' => 0,
    'display_right_block_bottom' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07a0e1949_00715809',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07a0e1949_00715809')) {function content_5ad1b07a0e1949_00715809($_smarty_tpl) {?>
<?php echo lang_get_smarty(array('var'=>"labels",'s'=>"current_test_plan,ok,testplan_role,msg_no_rights_for_tp,
             title_test_execution,href_execute_test,href_rep_and_metrics,
             href_update_tplan,href_newest_tcversions,title_plugins,
             href_my_testcase_assignments,href_platform_assign,
             href_tc_exec_assignment,href_plan_assign_urgency,
             href_upd_mod_tc,title_test_plan_mgmt,title_test_case_suite,
             href_plan_management,href_assign_user_roles,
             href_build_new,href_plan_mstones,href_plan_define_priority,
             href_metrics_dashboard,href_add_remove_test_cases,
             href_exec_ro_access"),$_smarty_tpl);?>


<?php $_smarty_tpl->tpl_vars['planView'] = new Smarty_variable("lib/plan/planView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['buildView'] = new Smarty_variable("lib/plan/buildView.php?tplan_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['mileView'] = new Smarty_variable("lib/plan/planMilestonesView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['platformAssign'] = new Smarty_variable("lib/platforms/platformsAssign.php?tplan_id=", null, 0);?>

<?php $_smarty_tpl->tpl_vars['menuLayout'] = new Smarty_variable($_smarty_tpl->tpl_vars['tlCfg']->value->gui->layoutMainPageRight, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_right_block_1'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_right_block_2'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_right_block_3'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_top'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_bottom'] = new Smarty_variable(false, null, 0);?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_planning']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['mgt_testplan_create']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['testplan_user_role_assignment']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['testplan_create_build']=="yes"){?>
   <?php $_smarty_tpl->tpl_vars['display_right_block_1'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->countPlans>0&&($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_execute']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['testplan_metrics']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['exec_ro_access']=="yes")){?>
   <?php $_smarty_tpl->tpl_vars['display_right_block_2'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->countPlans>0&&$_smarty_tpl->tpl_vars['gui']->value->grants['testplan_planning']=="yes"){?>
   <?php $_smarty_tpl->tpl_vars['display_right_block_3'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php $_smarty_tpl->tpl_vars['display_right_block_top'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_right_block_bottom'] = new Smarty_variable(false, null, 0);?>

<?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_TOP'])&&$_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_TOP']){?>
  <?php $_smarty_tpl->tpl_vars['display_right_block_top'] = new Smarty_variable(true, null, 0);?>
<?php }?>
<?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_BOTTOM'])&&$_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_BOTTOM']){?>
  <?php $_smarty_tpl->tpl_vars['display_right_block_bottom'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php $_smarty_tpl->tpl_vars['divStyle'] = new Smarty_variable("width:300px;padding: 0px 0px 0px 10px;", null, 0);?>
<?php $_smarty_tpl->tpl_vars['aStyle'] = new Smarty_variable("padding: 3px 15px;font-size:16px", null, 0);?>

<div class="vertical_menu" style="float: right; margin:0px 0px 10px 10px;width: 320px;">
	<?php if ($_smarty_tpl->tpl_vars['gui']->value->num_active_tplans>0){?>
	  <div class="" style="padding: 3px 15px;">
     <?php echo lang_get_smarty(array('s'=>'help','var'=>'common_prefix'),$_smarty_tpl);?>

     <?php echo lang_get_smarty(array('s'=>'test_plan','var'=>"xx_alt"),$_smarty_tpl);?>

     <?php $_smarty_tpl->tpl_vars['text_hint'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['common_prefix']->value).": ".((string)$_smarty_tpl->tpl_vars['xx_alt']->value), null, 0);?>
     <?php echo $_smarty_tpl->getSubTemplate ("inc_help.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('helptopic'=>"hlp_testPlan",'show_help_icon'=>true,'inc_help_alt'=>((string)$_smarty_tpl->tpl_vars['text_hint']->value),'inc_help_title'=>((string)$_smarty_tpl->tpl_vars['text_hint']->value),'inc_help_style'=>"float: right;vertical-align: top;"), 0);?>


 	   <form name="testplanForm" action="lib/general/mainPage.php">
       <?php if ($_smarty_tpl->tpl_vars['gui']->value->countPlans>0){?>
		     <?php echo $_smarty_tpl->tpl_vars['labels']->value['current_test_plan'];?>
:<br/>
		     <select class="chosen-select" name="testplan" onchange="this.form.submit();">
		     	<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['name'] = 'tPlan';
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['gui']->value->arrPlans) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['tPlan']['total']);
?>
		     		<option value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->arrPlans[$_smarty_tpl->getVariable('smarty')->value['section']['tPlan']['index']]['id'];?>
"
		     		        <?php if ($_smarty_tpl->tpl_vars['gui']->value->arrPlans[$_smarty_tpl->getVariable('smarty')->value['section']['tPlan']['index']]['selected']){?> selected="selected" <?php }?>
		     		        title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->arrPlans[$_smarty_tpl->getVariable('smarty')->value['section']['tPlan']['index']]['name'], ENT_QUOTES, 'UTF-8', true);?>
">
		     		        <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->arrPlans[$_smarty_tpl->getVariable('smarty')->value['section']['tPlan']['index']]['name'], ENT_QUOTES, 'UTF-8', true);?>

		     		</option>
		     	<?php endfor; endif; ?>
		     </select>
		     
		     <?php if ($_smarty_tpl->tpl_vars['gui']->value->countPlans==1){?>
		     	<input type="button" onclick="this.form.submit();" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['ok'];?>
"/>
		     <?php }?>
		     
		     <?php if ($_smarty_tpl->tpl_vars['gui']->value->testplanRole!=null){?>
		     	<br /><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_role'];?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->testplanRole, ENT_QUOTES, 'UTF-8', true);?>

		     <?php }?>
	     <?php }else{ ?>
         <?php if ($_smarty_tpl->tpl_vars['gui']->value->num_active_tplans>0){?><?php echo $_smarty_tpl->tpl_vars['labels']->value['msg_no_rights_for_tp'];?>
<?php }?>
		   <?php }?>
	   </form>
	  </div>
  <?php }?>
  <br />

   <?php if ($_smarty_tpl->tpl_vars['display_right_block_top']->value){?>
    <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_TOP'])){?>
      <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
" id="plugin_right_top">
        <?php  $_smarty_tpl->tpl_vars['menu_item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_TOP']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_item']->key => $_smarty_tpl->tpl_vars['menu_item']->value){
$_smarty_tpl->tpl_vars['menu_item']->_loop = true;
?>
		  <a href="<?php echo $_smarty_tpl->tpl_vars['menu_item']->value['href'];?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['menu_item']->value['label'];?>
</a>
          <br/>
        <?php } ?>
      </div>
    <?php }?>
  <?php }?>

  
  <?php if ($_smarty_tpl->tpl_vars['display_right_block_1']->value){?>
    <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['mgt_testplan_create']=="yes"){?>
       		<a href="<?php echo $_smarty_tpl->tpl_vars['planView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_plan_management'];?>
</a>
	    <?php }?>
	    
	    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_create_build']=="yes"&&$_smarty_tpl->tpl_vars['gui']->value->countPlans>0){?>
       	<a href="<?php echo $_smarty_tpl->tpl_vars['buildView']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testplanID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_build_new'];?>
</a>
      <?php }?>
	    
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_milestone_overview']=="yes"&&$_smarty_tpl->tpl_vars['gui']->value->countPlans>0){?>
         <a href="<?php echo $_smarty_tpl->tpl_vars['mileView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_plan_mstones'];?>
</a>
      <?php }?>
    </div>
  <?php }?>

  <?php if ($_smarty_tpl->tpl_vars['display_right_block_2']->value){?>
    <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
	<?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_execute']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['exec_ro_access']=="yes"){?>

        <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_execute']=="yes"){?>
          <?php $_smarty_tpl->tpl_vars['lbx'] = new Smarty_variable($_smarty_tpl->tpl_vars['labels']->value['href_execute_test'], null, 0);?>
        <?php }?>

        <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['exec_ro_access']=="yes"){?>  
          <?php $_smarty_tpl->tpl_vars['lbx'] = new Smarty_variable($_smarty_tpl->tpl_vars['labels']->value['href_exec_ro_access'], null, 0);?>
        <?php }?>

		<a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=executeTest" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['lbx']->value;?>
</a>

      <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['exec_testcases_assigned_to_me']=="yes"){?>
			 <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->url['testcase_assignments'];?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_my_testcase_assignments'];?>
</a>
      <?php }?> 
		<?php }?> 
      
		<?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_metrics']=="yes"){?>
			<a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=showMetrics" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_rep_and_metrics'];?>
</a>
  			<a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->url['metrics_dashboard'];?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_metrics_dashboard'];?>
</a>
		<?php }?> 
    </div>
	<?php }?>

	<?php if ($_smarty_tpl->tpl_vars['display_right_block_3']->value){?>
    <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_add_remove_platforms']=="yes"){?>
  	  <a href="<?php echo $_smarty_tpl->tpl_vars['platformAssign']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testplanID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_platform_assign'];?>
</a>
    <?php }?> 
		
	  <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=planAddTC" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_add_remove_test_cases'];?>
</a>

    <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=tc_exec_assignment" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_tc_exec_assignment'];?>
</a>
		
    <?php if ($_smarty_tpl->tpl_vars['session']->value['testprojectOptions']->testPriorityEnabled&&$_smarty_tpl->tpl_vars['gui']->value->grants['testplan_set_urgent_testcases']=="yes"){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=test_urgency" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_plan_assign_urgency'];?>
</a>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_update_linked_testcase_versions']=="yes"){?>
	   	<a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=planUpdateTC" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_update_tplan'];?>
</a>
    <?php }?> 

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['testplan_show_testcases_newest_versions']=="yes"){?>
	   	<a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=newest_tcversions" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_newest_tcversions'];?>
</a>
    <?php }?> 

    </div>
  <?php }?>

  <?php if ($_smarty_tpl->tpl_vars['display_right_block_bottom']->value){?>
    <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_BOTTOM'])){?>
	  <br/>
	  <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
" id="plugin_right_bottom">
        <?php  $_smarty_tpl->tpl_vars['menu_item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_RIGHTMENU_BOTTOM']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_item']->key => $_smarty_tpl->tpl_vars['menu_item']->value){
$_smarty_tpl->tpl_vars['menu_item']->_loop = true;
?>
		  <a href="<?php echo $_smarty_tpl->tpl_vars['menu_item']->value['href'];?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['menu_item']->value['label'];?>
</a>
        <?php } ?>
      </div>
    <?php }?>  
  <?php }?>
  

</div>
<script>
jQuery( document ).ready(function() {
jQuery(".chosen-select").chosen({ width: "85%" });
});
</script>
<?php }} ?>