<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:46
         compiled from "/development/release/latest/gui/templates/inc_update.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17714958155ad1b07e83ec48-35355274%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '921b474d7e945c552b6307667569a2a9e3d7ebef' => 
    array (
      0 => '/development/release/latest/gui/templates/inc_update.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17714958155ad1b07e83ec48-35355274',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'user_feedback' => 0,
    'feedback_type' => 0,
    'msg' => 0,
    'result' => 0,
    'action' => 0,
    'item' => 0,
    'name' => 0,
    'refresh' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07e9397a8_52881894',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07e9397a8_52881894')) {function content_5ad1b07e9397a8_52881894($_smarty_tpl) {?>


<?php if ($_smarty_tpl->tpl_vars['user_feedback']->value!=''){?>
    <?php if ($_smarty_tpl->tpl_vars['feedback_type']->value!=''){?>
    	<div class="<?php echo $_smarty_tpl->tpl_vars['feedback_type']->value;?>
">
  	<?php }else{ ?>
     <div class="user_feedback">
  	 <?php }?>
		<?php  $_smarty_tpl->tpl_vars['msg'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['msg']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['user_feedback']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['msg']->key => $_smarty_tpl->tpl_vars['msg']->value){
$_smarty_tpl->tpl_vars['msg']->_loop = true;
?>
			<p><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['msg']->value, ENT_QUOTES, 'UTF-8', true);?>
</p>
		<?php } ?>
     </div>

<?php }else{ ?>
  <?php if ($_smarty_tpl->tpl_vars['result']->value=="ok"){?>
  
    <?php echo lang_get_smarty(array('s'=>$_smarty_tpl->tpl_vars['action']->value,'var'=>'action'),$_smarty_tpl);?>

  	<?php echo lang_get_smarty(array('s'=>$_smarty_tpl->tpl_vars['item']->value,'var'=>'item'),$_smarty_tpl);?>

  	
    <?php if ($_smarty_tpl->tpl_vars['feedback_type']->value=="soft"){?>
    	<div class="warning_<?php echo $_smarty_tpl->tpl_vars['feedback_type']->value;?>
">	
  		<p><?php echo (($tmp = @$_smarty_tpl->tpl_vars['item']->value)===null||$tmp==='' ? "item" : $tmp);?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
</p> 
        	<p><?php echo lang_get_smarty(array('s'=>'was_success'),$_smarty_tpl);?>
 <?php echo (($tmp = @$_smarty_tpl->tpl_vars['action']->value)===null||$tmp==='' ? "updated" : $tmp);?>
!</p>
    	</div>
  	<?php }else{ ?>
    	<div class="user_feedback">
  	  	<p><?php echo (($tmp = @$_smarty_tpl->tpl_vars['item']->value)===null||$tmp==='' ? "item" : $tmp);?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>
 
           <?php echo lang_get_smarty(array('s'=>'was_success'),$_smarty_tpl);?>
 <?php echo (($tmp = @$_smarty_tpl->tpl_vars['action']->value)===null||$tmp==='' ? "updated" : $tmp);?>
!</p>
  	</div>
    <?php }?>
    
  
  <?php }elseif($_smarty_tpl->tpl_vars['result']->value!=''){?>
  
    <?php if ($_smarty_tpl->tpl_vars['feedback_type']->value=="soft"){?>
  		<div class="warning_<?php echo $_smarty_tpl->tpl_vars['feedback_type']->value;?>
">	
  		  <p><?php echo lang_get_smarty(array('s'=>'warning'),$_smarty_tpl);?>
</p> 
  			<p><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['result']->value, ENT_QUOTES, 'UTF-8', true);?>
</p>
    	</div>
  	<?php }else{ ?>
    	<div class="error">
        <p>
    		<?php if ($_smarty_tpl->tpl_vars['name']->value==''){?>
    			<?php echo lang_get_smarty(array('s'=>'info_failed_db_upd'),$_smarty_tpl);?>

    		<?php }else{ ?>
    			<?php echo lang_get_smarty(array('s'=>'info_failed_db_upd_details'),$_smarty_tpl);?>
 <?php echo (($tmp = @$_smarty_tpl->tpl_vars['item']->value)===null||$tmp==='' ? "item" : $tmp);?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8', true);?>

    		<?php }?>
        </p>
    		<p><?php echo lang_get_smarty(array('s'=>'invalid_query'),$_smarty_tpl);?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['result']->value, ENT_QUOTES, 'UTF-8', true);?>
</p>
    	</div>
  	<?php }?>
  <?php }?>
<?php }?>  

<?php if ($_smarty_tpl->tpl_vars['result']->value=="ok"&&isset($_smarty_tpl->tpl_vars['refresh']->value)&&$_smarty_tpl->tpl_vars['refresh']->value){?>
	<?php echo $_smarty_tpl->getSubTemplate ("inc_refreshTreeWithFilters.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }?><?php }} ?>