<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:42
         compiled from "/development/release/latest/gui/templates/mainPageLeft.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14458929835ad1b07a122ee3-67647537%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '551132ef049458f84fa77a636b7133a63727608d' => 
    array (
      0 => '/development/release/latest/gui/templates/mainPageLeft.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14458929835ad1b07a122ee3-67647537',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tlCfg' => 0,
    'gui' => 0,
    'display_left_block_top' => 0,
    'divStyle' => 0,
    'menu_item' => 0,
    'aStyle' => 0,
    'display_left_block_2' => 0,
    'cfieldsView' => 0,
    'labels' => 0,
    'issueTrackerView' => 0,
    'codeTrackerView' => 0,
    'display_left_block_1' => 0,
    'projectView' => 0,
    'usersAssign' => 0,
    'cfAssignment' => 0,
    'keywordsAssignment' => 0,
    'platformsView' => 0,
    'inventoryView' => 0,
    'display_left_block_3' => 0,
    'reqOverView' => 0,
    'assignReq' => 0,
    'reqMonOverView' => 0,
    'display_left_block_4' => 0,
    'tcSearch' => 0,
    'tcCreatedUser' => 0,
    'display_left_block_bottom' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07a528b11_16624842',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07a528b11_16624842')) {function content_5ad1b07a528b11_16624842($_smarty_tpl) {?>
<?php echo lang_get_smarty(array('var'=>'labels','s'=>'title_product_mgmt,href_tproject_management,href_admin_modules,
   href_assign_user_roles,href_cfields_management,system_config,
   href_cfields_tproject_assign,href_keywords_manage,
   title_user_mgmt,href_user_management,
   href_roles_management,title_requirements,
   href_req_spec,href_req_assign,link_report_test_cases_created_per_user,
   title_test_spec,href_edit_tc,href_browse_tc,href_search_tc,
   href_search_req, href_search_req_spec,href_inventory,
   href_platform_management, href_inventory_management,
   href_print_tc,href_keywords_assign, href_req_overview,
   href_print_req,title_plugins,title_documentation,href_issuetracker_management,
   href_codetracker_management,href_reqmgrsystem_management,href_req_monitor_overview'),$_smarty_tpl);?>



<?php $_smarty_tpl->tpl_vars['display_left_block_1'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_2'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_3'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_4'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_5'] = new Smarty_variable($_smarty_tpl->tpl_vars['tlCfg']->value->userDocOnDesktop, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_top'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_bottom'] = new Smarty_variable(false, null, 0);?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->testprojectID&&($_smarty_tpl->tpl_vars['gui']->value->grants['project_edit']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['tproject_user_role_assignment']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['cfield_management']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['platform_management']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['keywords_view']=="yes")){?>
    
    <?php $_smarty_tpl->tpl_vars['display_left_block_1'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->testprojectID&&($_smarty_tpl->tpl_vars['gui']->value->grants['cfield_management']||$_smarty_tpl->tpl_vars['gui']->value->grants['cfield_assignment']||$_smarty_tpl->tpl_vars['gui']->value->grants['issuetracker_management']||$_smarty_tpl->tpl_vars['gui']->value->grants['codetracker_management']||$_smarty_tpl->tpl_vars['gui']->value->grants['issuetracker_view']||$_smarty_tpl->tpl_vars['gui']->value->grants['codetracker_view'])){?>
   <?php $_smarty_tpl->tpl_vars['display_left_block_2'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->testprojectID&&$_smarty_tpl->tpl_vars['gui']->value->opt_requirements==true&&($_smarty_tpl->tpl_vars['gui']->value->grants['reqs_view']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['reqs_edit']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['monitor_req']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['req_tcase_link_management']=="yes")){?>
    <?php $_smarty_tpl->tpl_vars['display_left_block_3'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->testprojectID&&$_smarty_tpl->tpl_vars['gui']->value->grants['view_tc']=="yes"){?>
    <?php $_smarty_tpl->tpl_vars['display_left_block_4'] = new Smarty_variable(true, null, 0);?>
<?php }?>

<?php $_smarty_tpl->tpl_vars['display_left_block_top'] = new Smarty_variable(false, null, 0);?>
<?php $_smarty_tpl->tpl_vars['display_left_block_bottom'] = new Smarty_variable(false, null, 0);?>

<?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_TOP'])&&$_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_TOP']){?>
  <?php $_smarty_tpl->tpl_vars['display_left_block_top'] = new Smarty_variable(true, null, 0);?>
<?php }?>
<?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_BOTTOM'])&&$_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_BOTTOM']){?>
  <?php $_smarty_tpl->tpl_vars['display_left_block_bottom'] = new Smarty_variable(true, null, 0);?>
<?php }?>



<?php $_smarty_tpl->tpl_vars['divStyle'] = new Smarty_variable("width:300px;padding: 0px 0px 0px 10px;", null, 0);?>
<?php $_smarty_tpl->tpl_vars['aStyle'] = new Smarty_variable("padding: 3px 15px;font-size:16px", null, 0);?>

<?php $_smarty_tpl->tpl_vars['projectView'] = new Smarty_variable("lib/project/projectView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['usersAssign'] = new Smarty_variable("lib/usermanagement/usersAssign.php?featureType=testproject&featureID=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['cfAssignment'] = new Smarty_variable("lib/cfields/cfieldsTprojectAssign.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['keywordsAssignment'] = new Smarty_variable("lib/keywords/keywordsView.php?tproject_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['platformsView'] = new Smarty_variable("lib/platforms/platformsView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['cfieldsView'] = new Smarty_variable("lib/cfields/cfieldsView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['issueTrackerView'] = new Smarty_variable("lib/issuetrackers/issueTrackerView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['codeTrackerView'] = new Smarty_variable("lib/codetrackers/codeTrackerView.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['reqOverView'] = new Smarty_variable("lib/requirements/reqOverview.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['reqMonOverView'] = new Smarty_variable("lib/requirements/reqMonitorOverview.php?tproject_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['tcSearch'] = new Smarty_variable("lib/testcases/tcSearch.php?doAction=userInput&tproject_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['tcCreatedUser'] = new Smarty_variable("lib/results/tcCreatedPerUserOnTestProject.php?do_action=uinput&tproject_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['assignReq'] = new Smarty_variable("lib/general/frmWorkArea.php?feature=assignReqs", null, 0);?>
<?php $_smarty_tpl->tpl_vars['inventoryView'] = new Smarty_variable("lib/inventory/inventoryView.php", null, 0);?>


<div class="vertical_menu" style="float: left; margin:0px 10px 10px 0px; width: 320px;">

  <?php if ($_smarty_tpl->tpl_vars['display_left_block_top']->value){?>
    <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_TOP'])){?>
      <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
" id="plugin_left_top">
        <?php  $_smarty_tpl->tpl_vars['menu_item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_TOP']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_item']->key => $_smarty_tpl->tpl_vars['menu_item']->value){
$_smarty_tpl->tpl_vars['menu_item']->_loop = true;
?>
		  <a href="<?php echo $_smarty_tpl->tpl_vars['menu_item']->value['href'];?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['menu_item']->value['label'];?>
</a>
          <br/>
        <?php } ?>
      </div>
    <?php }?>
  <?php }?>

<?php if ($_smarty_tpl->tpl_vars['display_left_block_2']->value){?>
  <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['cfield_management']=="yes"){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['cfieldsView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_cfields_management'];?>
</a>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['issuetracker_management']||$_smarty_tpl->tpl_vars['gui']->value->grants['issuetracker_view']){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['issueTrackerView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_issuetracker_management'];?>
</a>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['codetracker_management']||$_smarty_tpl->tpl_vars['gui']->value->grants['codetracker_view']){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['codeTrackerView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
">
      <?php echo $_smarty_tpl->tpl_vars['labels']->value['href_codetracker_management'];?>
</a>
    <?php }?>
  </div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['display_left_block_1']->value){?>
  <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['project_edit']=="yes"){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['projectView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
">
        <?php echo $_smarty_tpl->tpl_vars['labels']->value['href_tproject_management'];?>
</a>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['tproject_user_role_assignment']=="yes"){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['usersAssign']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testprojectID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_assign_user_roles'];?>
</a>
    <?php }?>
    
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['cfield_management']=="yes"){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['cfAssignment']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_cfields_tproject_assign'];?>
</a>
    <?php }?>
    
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['keywords_view']=="yes"){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['keywordsAssignment']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testprojectID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_keywords_manage'];?>
</a>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['platform_management']||$_smarty_tpl->tpl_vars['gui']->value->grants['platform_view']){?>
      <a href="<?php echo $_smarty_tpl->tpl_vars['platformsView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_platform_management'];?>
</a>
    <?php }?>
    
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['project_inventory_view']||$_smarty_tpl->tpl_vars['gui']->value->grants['project_inventory_management']){?>
       <a href="<?php echo $_smarty_tpl->tpl_vars['inventoryView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_inventory_management'];?>
</a>
    <?php }?>


  </div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['display_left_block_3']->value){?>
  <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
       <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['reqs_view']=="yes"||$_smarty_tpl->tpl_vars['gui']->value->grants['reqs_edit']=="yes"){?>
          <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=reqSpecMgmt" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_req_spec'];?>
</a>
          <a href="<?php echo $_smarty_tpl->tpl_vars['reqOverView']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_req_overview'];?>
</a>
          <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=printReqSpec" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_print_req'];?>
</a>
          <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=searchReq" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_search_req'];?>
</a>
          <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=searchReqSpec" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_search_req_spec'];?>
</a>
       <?php }?>
       <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['req_tcase_link_management']=="yes"){?>
          <a href="<?php echo $_smarty_tpl->tpl_vars['assignReq']->value;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_req_assign'];?>
</a>
       <?php }?>
       <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['monitor_req']=="yes"){?>
          <a href="<?php echo $_smarty_tpl->tpl_vars['reqMonOverView']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testprojectID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_req_monitor_overview'];?>
</a>
      <?php }?>
  </div>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['display_left_block_4']->value){?>
    <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
">
      <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=editTc" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
">
        <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['modify_tc']=="yes"){?>
          <?php echo lang_get_smarty(array('s'=>'href_edit_tc'),$_smarty_tpl);?>

       <?php }else{ ?>
          <?php echo lang_get_smarty(array('s'=>'href_browse_tc'),$_smarty_tpl);?>

       <?php }?>
      </a>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->hasTestCases){?>
        <a href="<?php echo $_smarty_tpl->tpl_vars['tcSearch']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testprojectID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_search_tc'];?>
</a>
      <?php }?>    
      
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->hasKeywords){?>  
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['keyword_assignment']=="yes"){?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['gui']->value->launcher;?>
?feature=keywordsAssign" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['href_keywords_assign'];?>
</a>
      <?php }?>
    <?php }?>
      
     <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants['modify_tc']=="yes"){?>
       <a href="<?php echo $_smarty_tpl->tpl_vars['tcCreatedUser']->value;?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->testprojectID;?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['link_report_test_cases_created_per_user'];?>
</a>
     <?php }?>
    
    </div>
<?php }?>

  <?php if ($_smarty_tpl->tpl_vars['display_left_block_bottom']->value){?>
    <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_BOTTOM'])){?>
	  <br/>
	  <div class="list-group" style="<?php echo $_smarty_tpl->tpl_vars['divStyle']->value;?>
" id="plugin_left_bottom">
        <?php  $_smarty_tpl->tpl_vars['menu_item'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['menu_item']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->plugins['EVENT_LEFTMENU_BOTTOM']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['menu_item']->key => $_smarty_tpl->tpl_vars['menu_item']->value){
$_smarty_tpl->tpl_vars['menu_item']->_loop = true;
?>
		  <a href="<?php echo $_smarty_tpl->tpl_vars['menu_item']->value['href'];?>
" class="list-group-item" style="<?php echo $_smarty_tpl->tpl_vars['aStyle']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['menu_item']->value['label'];?>
</a>
        <?php } ?>
      </div>
    <?php }?>  
  <?php }?>
  
</div>
<?php }} ?>