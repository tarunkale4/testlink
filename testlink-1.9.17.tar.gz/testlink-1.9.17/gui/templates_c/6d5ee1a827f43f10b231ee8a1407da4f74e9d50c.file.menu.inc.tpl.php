<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:33
         compiled from "/development/release/latest/gui/templates/usermanagement/menu.inc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11649120385ad1b0ad363e09-16692267%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6d5ee1a827f43f10b231ee8a1407da4f74e9d50c' => 
    array (
      0 => '/development/release/latest/gui/templates/usermanagement/menu.inc.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11649120385ad1b0ad363e09-16692267',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'lib' => 0,
    'act' => 0,
    'ak' => 0,
    'gui' => 0,
    'menuLbl' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0ad450150_31690107',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0ad450150_31690107')) {function content_5ad1b0ad450150_31690107($_smarty_tpl) {?>


<?php $_smarty_tpl->tpl_vars['lib'] = new Smarty_variable('lib/usermanagement', null, 0);?>
<?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value['view_users']['url'] = ($_smarty_tpl->tpl_vars['lib']->value).('/usersView.php');?>
<?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value['view_roles']['url'] = ($_smarty_tpl->tpl_vars['lib']->value).('/rolesView.php');?>
<?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value['assign_users_tproject']['url'] = ($_smarty_tpl->tpl_vars['lib']->value).('/usersAssign.php?featureType=testproject');?>
<?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value['assign_users_tplan']['url'] = ($_smarty_tpl->tpl_vars['lib']->value).('/usersAssign.php?featureType=testplan');?>


<?php echo lang_get_smarty(array('var'=>"menuLbl",'s'=>"menu_new_user,menu_view_users,menu_edit_user,menu_define_roles,menu_edit_role,menu_view_roles,menu_assign_testproject_roles,menu_assign_testplan_roles"),$_smarty_tpl);?>


<?php  $_smarty_tpl->tpl_vars['mx'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['mx']->_loop = false;
 $_smarty_tpl->tpl_vars['ak'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['act']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['mx']->key => $_smarty_tpl->tpl_vars['mx']->value){
$_smarty_tpl->tpl_vars['mx']->_loop = true;
 $_smarty_tpl->tpl_vars['ak']->value = $_smarty_tpl->tpl_vars['mx']->key;
?>
  <?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value[$_smarty_tpl->tpl_vars['ak']->value]['class'] = '';?>
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->highlight->{$_smarty_tpl->tpl_vars['ak']->value}==1){?>
    <?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value[$_smarty_tpl->tpl_vars['ak']->value]['class'] = ' class="active" ';?>
  <?php }?>
<?php } ?>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->user_mgmt=="no"){?>
  <?php $_smarty_tpl->createLocalArrayVariable('act', null, 0);
$_smarty_tpl->tpl_vars['act']->value[$_smarty_tpl->tpl_vars['ak']->value]['class'] = '';?>
<?php }?>

<div class="container">
  <ul class="nav nav-pills">

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->user_mgmt=="yes"){?>
	    <li <?php echo $_smarty_tpl->tpl_vars['act']->value['view_users']['class'];?>
 ><a href="<?php echo $_smarty_tpl->tpl_vars['act']->value['view_users']['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['menuLbl']->value['menu_view_users'];?>
</a></li>
	  <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->role_mgmt=="yes"){?>    
      <li <?php echo $_smarty_tpl->tpl_vars['act']->value['view_roles']['class'];?>
 ><a href="<?php echo $_smarty_tpl->tpl_vars['act']->value['view_roles']['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['menuLbl']->value['menu_view_roles'];?>
</a></li>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->tproject_user_role_assignment=="yes"){?>
      <li <?php echo $_smarty_tpl->tpl_vars['act']->value['assign_users_tproject']['class'];?>
 ><a href="<?php echo $_smarty_tpl->tpl_vars['act']->value['assign_users_tproject']['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['menuLbl']->value['menu_assign_testproject_roles'];?>
</a></li>
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->tplan_user_role_assignment=="yes"){?>
      <li <?php echo $_smarty_tpl->tpl_vars['act']->value['assign_users_tplan']['class'];?>
 ><a href="<?php echo $_smarty_tpl->tpl_vars['act']->value['assign_users_tplan']['url'];?>
"><?php echo $_smarty_tpl->tpl_vars['menuLbl']->value['menu_assign_testplan_roles'];?>
</a></li>
    <?php }?>

  </ul>  
</div><?php }} ?>