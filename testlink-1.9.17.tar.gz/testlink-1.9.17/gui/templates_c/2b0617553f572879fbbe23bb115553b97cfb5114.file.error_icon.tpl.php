<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:13
         compiled from "/development/release/latest/gui/templates/error_icon.tpl" */ ?>
<?php /*%%SmartyHeaderCode:587425045ad1b05dc1cf22-64302684%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2b0617553f572879fbbe23bb115553b97cfb5114' => 
    array (
      0 => '/development/release/latest/gui/templates/error_icon.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '587425045ad1b05dc1cf22-64302684',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'field' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b05dc2e036_98602574',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b05dc2e036_98602574')) {function content_5ad1b05dc2e036_98602574($_smarty_tpl) {?>
<img id="error_icon_<?php echo $_smarty_tpl->tpl_vars['field']->value;?>
" style="visibility: hidden;" 
     src="<?php echo @constant('TL_THEME_IMG_DIR');?>
/error.gif" alt="error condition detected" 
     title="error condition detected" width="1" height="1" />
<?php }} ?>