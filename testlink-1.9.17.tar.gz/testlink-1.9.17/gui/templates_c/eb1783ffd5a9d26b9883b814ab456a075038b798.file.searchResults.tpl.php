<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:52
         compiled from "/development/release/latest/gui/templates/search/searchResults.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17799716195ad1b0c008d839-98847813%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb1783ffd5a9d26b9883b814ab456a075038b798' => 
    array (
      0 => '/development/release/latest/gui/templates/search/searchResults.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17799716195ad1b0c008d839-98847813',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gui' => 0,
    'matrix' => 0,
    'tableID' => 0,
    'gsmarty_timestamp_format' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0c0218ac0_44230745',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0c0218ac0_44230745')) {function content_5ad1b0c0218ac0_44230745($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.date_format.php';
?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>'yes'), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_jsCheckboxes.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_ext_js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('bResetEXTCss'=>1), 0);?>


<?php  $_smarty_tpl->tpl_vars['matrix'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['matrix']->_loop = false;
 $_smarty_tpl->tpl_vars['idx'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tableSet; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['matrix']->index=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['matrix']->key => $_smarty_tpl->tpl_vars['matrix']->value){
$_smarty_tpl->tpl_vars['matrix']->_loop = true;
 $_smarty_tpl->tpl_vars['idx']->value = $_smarty_tpl->tpl_vars['matrix']->key;
 $_smarty_tpl->tpl_vars['matrix']->index++;
 $_smarty_tpl->tpl_vars['matrix']->first = $_smarty_tpl->tpl_vars['matrix']->index === 0;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']["initializer"]['first'] = $_smarty_tpl->tpl_vars['matrix']->first;
?>
  <?php $_smarty_tpl->tpl_vars['tableID'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['matrix']->value)."->tableID", null, 0);?>
  <?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['initializer']['first']){?>
    <?php echo $_smarty_tpl->tpl_vars['matrix']->value->renderCommonGlobals();?>

    <?php if ($_smarty_tpl->tpl_vars['matrix']->value instanceof tlExtTable){?>
        <?php echo $_smarty_tpl->getSubTemplate ("inc_ext_js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('bResetEXTCss'=>1), 0);?>

        <?php echo $_smarty_tpl->getSubTemplate ("inc_ext_table.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

    <?php }?>
  <?php }?>
  <?php echo $_smarty_tpl->tpl_vars['matrix']->value->renderHeadSection();?>

<?php } ?>

</head>

<body>
<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['gui']->value->pageTitle;?>
</h1>
<?php echo $_smarty_tpl->getSubTemplate ("search/searchGUI.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<?php if ($_smarty_tpl->tpl_vars['gui']->value->doSearch){?>
  <div class="workBack">
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->warning_msg==''){?>
    <?php  $_smarty_tpl->tpl_vars['matrix'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['matrix']->_loop = false;
 $_smarty_tpl->tpl_vars['idx'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tableSet; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['matrix']->key => $_smarty_tpl->tpl_vars['matrix']->value){
$_smarty_tpl->tpl_vars['matrix']->_loop = true;
 $_smarty_tpl->tpl_vars['idx']->value = $_smarty_tpl->tpl_vars['matrix']->key;
?>
      <?php $_smarty_tpl->tpl_vars['tableIDe'] = new Smarty_variable("table_".((string)$_smarty_tpl->tpl_vars['idx']->value), null, 0);?>
      <?php echo $_smarty_tpl->tpl_vars['matrix']->value->renderBodySection($_smarty_tpl->tpl_vars['tableID']->value);?>

    <?php } ?>
    <br />
    <?php echo lang_get_smarty(array('s'=>'generated_by_TestLink_on'),$_smarty_tpl);?>
 <?php echo smarty_modifier_date_format(time(),$_smarty_tpl->tpl_vars['gsmarty_timestamp_format']->value);?>

  <?php }else{ ?>
    <div class="user_feedback">
    <br />
    <?php echo $_smarty_tpl->tpl_vars['gui']->value->warning_msg;?>

    </div>
  <?php }?>
<?php }?>    
</div>
</body>
</html><?php }} ?>