<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:13
         compiled from "/development/release/latest/gui/templates/inc_jsCfieldsValidation.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1697116945ad1b05d9247a9-36582759%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7fa2ae7ff6e7c58ca3cc33b29e8acc6235a1def1' => 
    array (
      0 => '/development/release/latest/gui/templates/inc_jsCfieldsValidation.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1697116945ad1b05d9247a9-36582759',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cf_warning_msg' => 0,
    'tlCfg' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b05d96e755_24110932',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b05d96e755_24110932')) {function content_5ad1b05d96e755_24110932($_smarty_tpl) {?>
<?php echo lang_get_smarty(array('var'=>"cf_warning_msg",'s'=>"warning_numeric_cf,warning_float_cf,warning_email_cf,warning_text_area_cf"),$_smarty_tpl);?>


<script type="text/javascript" src='gui/javascript/cfield_validation.js'></script>


<script type="text/javascript">

var cfMessages= new Object;
cfMessages.warning_numeric_cf="<?php echo $_smarty_tpl->tpl_vars['cf_warning_msg']->value['warning_numeric_cf'];?>
";
cfMessages.warning_float_cf="<?php echo $_smarty_tpl->tpl_vars['cf_warning_msg']->value['warning_float_cf'];?>
";
cfMessages.warning_email_cf="<?php echo $_smarty_tpl->tpl_vars['cf_warning_msg']->value['warning_email_cf'];?>
";
cfMessages.warning_text_area_cf="<?php echo $_smarty_tpl->tpl_vars['cf_warning_msg']->value['warning_text_area_cf'];?>
";


var cfChecks = new Object;
cfChecks.email = <?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->validation_cfg->user_email_valid_regex_js;?>
;
cfChecks.textarea_length = <?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->custom_fields->max_length;?>
;

</script>
<?php }} ?>