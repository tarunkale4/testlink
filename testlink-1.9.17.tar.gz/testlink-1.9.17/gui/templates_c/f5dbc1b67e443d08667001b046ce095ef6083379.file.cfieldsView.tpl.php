<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:44
         compiled from "/development/release/latest/gui/templates/cfields/cfieldsView.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8763874555ad1b07c8bdcf7-41746698%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f5dbc1b67e443d08667001b046ce095ef6083379' => 
    array (
      0 => '/development/release/latest/gui/templates/cfields/cfieldsView.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8763874555ad1b07c8bdcf7-41746698',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'labels' => 0,
    'gui' => 0,
    'exportCfieldsAction' => 0,
    'importCfieldsAction' => 0,
    'tlImages' => 0,
    'noSortableColumnClass' => 0,
    'cf_def' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07ca464a5_52459505',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07ca464a5_52459505')) {function content_5ad1b07ca464a5_52459505($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>
<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>

<?php $_smarty_tpl->tpl_vars['cfViewAction'] = new Smarty_variable("lib/cfields/cfieldsView.php", null, 0);?>

<?php $_smarty_tpl->tpl_vars['cfImportAction'] = new Smarty_variable("lib/cfields/cfieldsImport.php?goback_url=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['importCfieldsAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['basehref']->value).((string)$_smarty_tpl->tpl_vars['cfImportAction']->value).((string)$_smarty_tpl->tpl_vars['basehref']->value).((string)$_smarty_tpl->tpl_vars['cfViewAction']->value), null, 0);?>

<?php $_smarty_tpl->tpl_vars['cfExportAction'] = new Smarty_variable("lib/cfields/cfieldsExport.php?goback_url=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['exportCfieldsAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['basehref']->value).((string)$_smarty_tpl->tpl_vars['cfExportAction']->value).((string)$_smarty_tpl->tpl_vars['basehref']->value).((string)$_smarty_tpl->tpl_vars['cfViewAction']->value), null, 0);?>


<?php echo lang_get_smarty(array('var'=>"labels",'s'=>"name,label,type,title_cfields_mgmt,manage_cfield,btn_cfields_create,
             btn_export,btn_import,btn_goback,sort_table_by_column,enabled_on_context,
             display_on_exec,available_on"),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('enableTableSorting'=>"yes"), 0);?>


<body>
<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['labels']->value['title_cfields_mgmt'];?>
</h1>
<div class="workBack">

<?php if ($_smarty_tpl->tpl_vars['gui']->value->cf_map!=''&&$_smarty_tpl->tpl_vars['gui']->value->drawControlsOnTop){?>
  <div class="groupBtn">
    <span style="float: left">
    <form method="post" action="lib/cfields/cfieldsEdit.php?do_action=create">
      <input type="submit" id="cfieldTop" name="create_cfield" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_cfields_create'];?>
" />
    </form>
    </span>
    <span>
    <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['exportCfieldsAction']->value;?>
" id="cfieldsExportTop" name="cfieldsExport">
      <input type="submit" name="export_cf" id="export_cfTop"
             style="margin-left: 3px;" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_export'];?>
" />
             
      <input type="button" name="import_cf" id="import_cfTop" 
             onclick="location='<?php echo $_smarty_tpl->tpl_vars['importCfieldsAction']->value;?>
'" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_import'];?>
" />
       
    </form>
    </span>
  </div>
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['gui']->value->cf_map!=''){?>
  <table id='item_view' class="simple_tableruler sortable">
  	<tr>
  		<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['name'];?>
</th>
  		<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['label'];?>
</th>
  		<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['type'];?>
</th>
      <th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['enabled_on_context'];?>
</th>
  		<th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['display_on_exec'];?>
</th>
  		<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['available_on'];?>
</th>
  	</tr>
  
   	<?php  $_smarty_tpl->tpl_vars['cf_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cf_def']->_loop = false;
 $_smarty_tpl->tpl_vars['cf_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cf_map; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cf_def']->key => $_smarty_tpl->tpl_vars['cf_def']->value){
$_smarty_tpl->tpl_vars['cf_def']->_loop = true;
 $_smarty_tpl->tpl_vars['cf_id']->value = $_smarty_tpl->tpl_vars['cf_def']->key;
?>
   	<tr>
   	<td width="20%" class="bold"><a href="lib/cfields/cfieldsEdit.php?do_action=edit&cfield_id=<?php echo $_smarty_tpl->tpl_vars['cf_def']->value['id'];?>
"
   	                    title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['manage_cfield'];?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf_def']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</a></td>
   	<td ><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf_def']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</td>
   	<td width="5%"><?php echo $_smarty_tpl->tpl_vars['gui']->value->cf_types[$_smarty_tpl->tpl_vars['cf_def']->value['type']];?>
</td>
    <td width="10%"><?php echo $_smarty_tpl->tpl_vars['cf_def']->value['enabled_on_context'];?>
</td>
   	<td align="center" width="5%"><?php if ($_smarty_tpl->tpl_vars['cf_def']->value['show_on_execution']){?><img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['checked'];?>
"><?php }?> </td>
   	<td width="10%"><?php echo lang_get_smarty(array('s'=>$_smarty_tpl->tpl_vars['cf_def']->value['node_description']),$_smarty_tpl);?>
</td>
   	
   	</tr>
   	<?php } ?>
  </table>
<?php }?> 
  
  <div class="groupBtn">
    <span style="float: left">
    <form method="post" action="lib/cfields/cfieldsEdit.php?do_action=create">
      <input type="submit" name="create_cfield" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_cfields_create'];?>
" />
    </form>
    </span>
    <span>
	  <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['exportCfieldsAction']->value;?>
" id="cfieldsExport" name="cfieldsExport">
		  <input type="submit" name="export_cf" id="export_cf"
		         style="margin-left: 3px;" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_export'];?>
" />
		         
		  <input type="button" name="import_cf" id="import_cf" 
		         onclick="location='<?php echo $_smarty_tpl->tpl_vars['importCfieldsAction']->value;?>
'" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_import'];?>
" />
       
	  </form>
	  </span>
  </div>

</div>
</body>
</html><?php }} ?>