<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:13
         compiled from "/development/release/latest/gui/templates/project/projectEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10454216995ad1b05d575180-67436717%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9729a917af8f2f451ee86980ace0d11841984edc' => 
    array (
      0 => '/development/release/latest/gui/templates/project/projectEdit.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10454216995ad1b05d575180-67436717',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'editorType' => 0,
    'gui_cfg' => 0,
    'labels' => 0,
    'main_descr' => 0,
    'tlCfg' => 0,
    'caption' => 0,
    'mgt_view_events' => 0,
    'gui' => 0,
    'tlImages' => 0,
    'user_feedback' => 0,
    'feedback_type' => 0,
    'managerURL' => 0,
    'testproject' => 0,
    'notes' => 0,
    'color' => 0,
    'basehref' => 0,
    'issue_tracker' => 0,
    'code_tracker' => 0,
    'doActionValue' => 0,
    'buttonValue' => 0,
    'sqlResult' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b05d8c1039_44211824',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b05d8c1039_44211824')) {function content_5ad1b05d8c1039_44211824($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>
<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>


<?php $_smarty_tpl->tpl_vars['managerURL'] = new Smarty_variable("lib/project/projectEdit.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['editAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?doAction=edit&tprojectID=", null, 0);?>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'show_event_history,th_active,cancel,info_failed_loc_prod,invalid_query,
  create_from_existent_tproject,opt_no,caption_edit_tproject,caption_new_tproject,name,
  title_testproject_management,testproject_enable_priority, testproject_enable_automation,
  public,testproject_color,testproject_alt_color,testproject_enable_requirements,
  testproject_enable_inventory,testproject_features,testproject_description,
  testproject_prefix,availability,mandatory,warning,warning_empty_tcase_prefix,api_key,
  warning_empty_tproject_name,testproject_issue_tracker_integration,issue_tracker,
  testproject_code_tracker_integration,code_tracker,testproject_reqmgr_integration,reqmgrsystem,
  no_rms_defined,no_issuetracker_defined,no_codetracker_defined'),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes",'jsValidate'=>"yes",'editorType'=>$_smarty_tpl->tpl_vars['editorType']->value), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<?php if ($_smarty_tpl->tpl_vars['gui_cfg']->value->testproject_coloring!='none'){?>
  <?php echo $_smarty_tpl->getSubTemplate ("inc_jsPicker.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php }?>

<script type="text/javascript">
var alert_box_title = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var warning_empty_tcase_prefix = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_empty_tcase_prefix'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var warning_empty_tproject_name = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_empty_tproject_name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";

function validateForm(f)
{
  if (isWhitespace(f.tprojectName.value))
  {
     alert_message(alert_box_title,warning_empty_tproject_name);
     selectField(f, 'tprojectName');
     return false;
  }
  if (isWhitespace(f.tcasePrefix.value))
  {
     alert_message(alert_box_title,warning_empty_tcase_prefix);
     selectField(f, 'tcasePrefix');
     return false;
  }

  return true;
}

/**
 *
 *
 */
function manageTracker(selectOID,targetOID)
{
  var so;
  var to;

  so = document.getElementById(selectOID);
  to = document.getElementById(targetOID);

  to.disabled = false;
  if(so.selectedIndex == 0)
  {
    to.checked = false;
    to.disabled = true;
  }  

}

</script>
</head>

<body onload="manageTracker('issue_tracker_id','issue_tracker_enabled');
manageTracker('code_tracker_id','code_tracker_enabled');">
<h1 class="title">
  <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['main_descr']->value, ENT_QUOTES, 'UTF-8', true);?>
  <?php echo $_smarty_tpl->tpl_vars['tlCfg']->value->gui_title_separator_1;?>

  <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['caption']->value, ENT_QUOTES, 'UTF-8', true);?>

  <?php if ($_smarty_tpl->tpl_vars['mgt_view_events']->value=="yes"&&$_smarty_tpl->tpl_vars['gui']->value->tprojectID){?>
    <img style="margin-left:5px;" class="clickable" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['help'];?>
" 
           onclick="showEventHistoryFor('<?php echo $_smarty_tpl->tpl_vars['gui']->value->tprojectID;?>
','testprojects')" 
           alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_event_history'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_event_history'];?>
"/>
  <?php }?>
</h1>

<?php if ($_smarty_tpl->tpl_vars['user_feedback']->value!=''){?>
  <?php echo $_smarty_tpl->getSubTemplate ("inc_update.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('user_feedback'=>$_smarty_tpl->tpl_vars['user_feedback']->value,'feedback_type'=>$_smarty_tpl->tpl_vars['feedback_type']->value), 0);?>

<?php }?>

<div class="workBack">
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->found=="yes"){?>
    <div style="width:80%; margin: auto;">
    <form name="edit_testproject" id="edit_testproject"
          method="post" action="<?php echo $_smarty_tpl->tpl_vars['managerURL']->value;?>
"
          onSubmit="javascript:return validateForm(this);">
    <table id="item_view" class="common" style="width:100%; padding:3px;">

      <?php if ($_smarty_tpl->tpl_vars['gui']->value->tprojectID==0){?>
        <?php if ($_smarty_tpl->tpl_vars['gui']->value->testprojects!=''){?>
       <tr>
         <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['create_from_existent_tproject'];?>
</td>
         <td>
           <select name="copy_from_tproject_id">
           <option value="0"><?php echo $_smarty_tpl->tpl_vars['labels']->value['opt_no'];?>
</option>
           <?php  $_smarty_tpl->tpl_vars['testproject'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['testproject']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->testprojects; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['testproject']->key => $_smarty_tpl->tpl_vars['testproject']->value){
$_smarty_tpl->tpl_vars['testproject']->_loop = true;
?>
             <option value="<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testproject']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</option>
           <?php } ?>
           </select>
         </td>
       </tr>
       <?php }?>
      <?php }?>
      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['name'];?>
 *</td>
        <td><input type="text" name="tprojectName" size="<?php echo $_smarty_tpl->getConfigVariable('TESTPROJECT_NAME_SIZE');?>
"
            value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->tprojectName, ENT_QUOTES, 'UTF-8', true);?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('TESTPROJECT_NAME_MAXLEN');?>
" required />
            <?php echo $_smarty_tpl->getSubTemplate ("error_icon.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('field'=>"tprojectName"), 0);?>

        </td>
      </tr>
      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_prefix'];?>
 *</td>
        <td><input type="text" name="tcasePrefix" size="<?php echo $_smarty_tpl->getConfigVariable('TESTCASE_PREFIX_SIZE');?>
"
                   value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->tcasePrefix, ENT_QUOTES, 'UTF-8', true);?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('TESTCASE_PREFIX_MAXLEN');?>
" required />
            <?php echo $_smarty_tpl->getSubTemplate ("error_icon.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('field'=>"tcasePrefix"), 0);?>

        </td>
      </tr>
      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_description'];?>
</td>
        <td style="width:80%"><?php echo $_smarty_tpl->tpl_vars['notes']->value;?>
</td>
      </tr>
      <?php if ($_smarty_tpl->tpl_vars['gui_cfg']->value->testproject_coloring!='none'){?>
      <tr>
        <th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_color'];?>
</th>
        <td>
          <input type="text" name="color" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['color']->value, ENT_QUOTES, 'UTF-8', true);?>
" maxlength="12" />
          
          <a href="javascript: TCP.popup(document.forms['edit_testproject'].elements['color'], '<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
third_party/color_picker/picker.html');">
            <img width="15" height="13" border="0" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_alt_color'];?>
"
            src="third_party/color_picker/img/sel.gif" />
          </a>
        </td>
      </tr>
      <?php }?>
      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_features'];?>
</td><td></td>
      </tr>
      <tr>
        <td></td><td>
            <input type="checkbox" name="optReq" 
                <?php if ($_smarty_tpl->tpl_vars['gui']->value->projectOptions->requirementsEnabled){?> checked="checked"  <?php }?> />
          <?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_enable_requirements'];?>

        </td>
      </tr>
      <tr>
        <td></td><td>
          <input type="checkbox" name="optPriority" 
              <?php if ($_smarty_tpl->tpl_vars['gui']->value->projectOptions->testPriorityEnabled){?> checked="checked"  <?php }?> />
          <?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_enable_priority'];?>

        </td>
      </tr>
      <tr>
        <td></td><td>
          <input type="checkbox" name="optAutomation" 
                <?php if ($_smarty_tpl->tpl_vars['gui']->value->projectOptions->automationEnabled){?> checked="checked" <?php }?> />
          <?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_enable_automation'];?>

        </td>
      </tr>
      <tr>
        <td></td><td>
          <input type="checkbox" name="optInventory" 
                <?php if ($_smarty_tpl->tpl_vars['gui']->value->projectOptions->inventoryEnabled){?> checked="checked" <?php }?> />
          <?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_enable_inventory'];?>

        </td>
      </tr>

      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_issue_tracker_integration'];?>
</td><td></td>
      </tr>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->issueTrackers==''){?>
        <tr>
          <td></td>
          <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['no_issuetracker_defined'];?>
</td>
        </tr>
      <?php }else{ ?>
        <tr>
          <td></td>
          <td>
            <input type="checkbox" id="issue_tracker_enabled"
                   name="issue_tracker_enabled" <?php if ($_smarty_tpl->tpl_vars['gui']->value->issue_tracker_enabled==1){?> checked="checked" <?php }?> />
            <?php echo $_smarty_tpl->tpl_vars['labels']->value['th_active'];?>

          </td>
        </tr>
        <tr>
          <td></td>
          <td>
            <?php echo $_smarty_tpl->tpl_vars['labels']->value['issue_tracker'];?>

             <select name="issue_tracker_id" id="issue_tracker_id"
             onchange="manageTracker('issue_tracker_id','issue_tracker_enabled');">
             <option value="0">&nbsp;</option>
             <?php  $_smarty_tpl->tpl_vars['issue_tracker'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['issue_tracker']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->issueTrackers; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['issue_tracker']->key => $_smarty_tpl->tpl_vars['issue_tracker']->value){
$_smarty_tpl->tpl_vars['issue_tracker']->_loop = true;
?>
               <option value="<?php echo $_smarty_tpl->tpl_vars['issue_tracker']->value['id'];?>
" 
                 <?php if ($_smarty_tpl->tpl_vars['issue_tracker']->value['id']==$_smarty_tpl->tpl_vars['gui']->value->issue_tracker_id){?> selected <?php }?> 
               >
               <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['issue_tracker']->value['verbose'], ENT_QUOTES, 'UTF-8', true);?>
</option>
             <?php } ?>
             </select>
          </td>
        </tr>
      <?php }?>

      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_code_tracker_integration'];?>
</td><td></td>
      </tr>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->codeTrackers==''){?>
        <tr>
          <td></td>
          <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['no_codetracker_defined'];?>
</td>
        </tr>
      <?php }else{ ?>
        <tr>
          <td></td>
          <td>
            <input type="checkbox" id="code_tracker_enabled"
                   name="code_tracker_enabled" <?php if ($_smarty_tpl->tpl_vars['gui']->value->code_tracker_enabled==1){?> checked="checked" <?php }?> />
            <?php echo $_smarty_tpl->tpl_vars['labels']->value['th_active'];?>

          </td>
        </tr>
        <tr>
          <td></td>
          <td>
            <?php echo $_smarty_tpl->tpl_vars['labels']->value['code_tracker'];?>

             <select name="code_tracker_id" id="code_tracker_id"
             onchange="manageTracker('code_tracker_id','code_tracker_enabled');">
             <option value="0">&nbsp;</option>
             <?php  $_smarty_tpl->tpl_vars['code_tracker'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['code_tracker']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->codeTrackers; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['code_tracker']->key => $_smarty_tpl->tpl_vars['code_tracker']->value){
$_smarty_tpl->tpl_vars['code_tracker']->_loop = true;
?>
               <option value="<?php echo $_smarty_tpl->tpl_vars['code_tracker']->value['id'];?>
" 
                 <?php if ($_smarty_tpl->tpl_vars['code_tracker']->value['id']==$_smarty_tpl->tpl_vars['gui']->value->code_tracker_id){?> selected <?php }?> 
               >
               <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['code_tracker']->value['verbose'], ENT_QUOTES, 'UTF-8', true);?>
</option>
             <?php } ?>
             </select>
          </td>
        </tr>
      <?php }?>
         
      

      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['availability'];?>
</td><td></td>
      </tr>
      <tr>
        <td></td><td>
            <input type="checkbox" name="active" <?php if ($_smarty_tpl->tpl_vars['gui']->value->active==1){?> checked="checked" <?php }?> />
            <?php echo $_smarty_tpl->tpl_vars['labels']->value['th_active'];?>

          </td>
          </tr>

      <tr>
        <td></td><td>
            <input type="checkbox" name="is_public" <?php if ($_smarty_tpl->tpl_vars['gui']->value->is_public==1){?> checked="checked"  <?php }?> />
            <?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>

          </td>
      </tr>
      
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->api_key!=''){?>
      <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['api_key'];?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['gui']->value->api_key;?>
</td>
      </tr>
      <?php }?>



      <tr><td cols="2">
        <?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage=="yes"){?>
        <div class="groupBtn">
          <input type="hidden" name="doAction" value="<?php echo $_smarty_tpl->tpl_vars['doActionValue']->value;?>
" />
          <input type="hidden" name="tprojectID" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tprojectID;?>
" />
          <input type="submit" name="doActionButton" value="<?php echo $_smarty_tpl->tpl_vars['buttonValue']->value;?>
" />
          <input type="button" name="go_back" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['cancel'];?>
" 
                 onclick="javascript: location.href=fRoot+'lib/project/projectView.php';" />
        </div>
      <?php }?>
      </td></tr>

    </table>
    </form>
    <p>* <?php echo $_smarty_tpl->tpl_vars['labels']->value['mandatory'];?>
</p>
  </div>
  <?php }else{ ?>
    <p class="info">
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->tprojectName!=''){?>
      <?php echo $_smarty_tpl->tpl_vars['labels']->value['info_failed_loc_prod'];?>
 - <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->tprojectName, ENT_QUOTES, 'UTF-8', true);?>
!<br />
    <?php }?>
    <?php echo $_smarty_tpl->tpl_vars['labels']->value['invalid_query'];?>
: <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['sqlResult']->value, ENT_QUOTES, 'UTF-8', true);?>
</p>
  <?php }?>
</div>
</body>
</html>
<?php }} ?>