<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:59
         compiled from "/development/release/latest/gui/templates/plan/planView.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12228346545ad1b08b156060-26397468%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '951cd783ef4f30e92affffc4ec2e2b2dfaa11bfc' => 
    array (
      0 => '/development/release/latest/gui/templates/plan/planView.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12228346545ad1b08b156060-26397468',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'deleteAction' => 0,
    'tlCfg' => 0,
    'll' => 0,
    'body_onload' => 0,
    'gui' => 0,
    'createAction' => 0,
    'labels' => 0,
    'managerURL' => 0,
    'tlImages' => 0,
    'noSortableColumnClass' => 0,
    'editAction' => 0,
    'testplan' => 0,
    'gsmarty_gui' => 0,
    'del_msgbox_title' => 0,
    'warning_msg' => 0,
    'exportAction' => 0,
    'importAction' => 0,
    'assignRolesAction' => 0,
    'gotoExecuteAction' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b08b437579_37499232',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b08b437579_37499232')) {function content_5ad1b08b437579_37499232($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>
<?php $_smarty_tpl->tpl_vars['managerURL'] = new Smarty_variable("lib/plan/planEdit.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['editAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?do_action=edit&amp;tplan_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['deleteAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?do_action=do_delete&tplan_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['createAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?do_action=create", null, 0);?>
<?php $_smarty_tpl->tpl_vars['exportAction'] = new Smarty_variable("lib/plan/planExport.php?tplan_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['importAction'] = new Smarty_variable("lib/plan/planImport.php?tplan_id=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['assignRolesAction'] = new Smarty_variable("lib/usermanagement/usersAssign.php?featureType=testplan&featureID=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['gotoExecuteAction'] = new Smarty_variable("lib/general/frmWorkArea.php?feature=executeTest&tplan_id=", null, 0);?>



<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'testplan_title_tp_management,testplan_txt_empty_list,sort_table_by_column,
          testplan_th_name,testplan_th_notes,testplan_th_active,testplan_th_delete,
          testplan_alt_edit_tp,alt_active_testplan,testplan_alt_delete_tp,public,
          btn_testplan_create,th_id,error_no_testprojects_present,btn_export_import,
          export_import,export,import,export_testplan_links,import_testplan_links,build_qty,
          testcase_qty,platform_qty,active_click_to_change,inactive_click_to_change,
          testcase_number_help,platform_number_help,build_number_help,assign_roles,execution'),$_smarty_tpl);?>



<?php echo lang_get_smarty(array('s'=>'warning_delete_testplan','var'=>"warning_msg"),$_smarty_tpl);?>

<?php echo lang_get_smarty(array('s'=>'delete','var'=>"del_msgbox_title"),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes",'enableTableSorting'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script type="text/javascript">
/* All this stuff is needed for logic contained in inc_del_onclick.tpl */
var del_action=fRoot+'<?php echo $_smarty_tpl->tpl_vars['deleteAction']->value;?>
';
</script>

<?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->gui->planView->pagination->enabled){?>
  <?php $_smarty_tpl->tpl_vars['ll'] = new Smarty_variable($_smarty_tpl->tpl_vars['tlCfg']->value->gui->planView->pagination->length, null, 0);?>
  <?php echo $_smarty_tpl->getSubTemplate ("DataTables.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('DataTablesOID'=>"item_view",'DataTableslengthMenu'=>$_smarty_tpl->tpl_vars['ll']->value), 0);?>

<?php }?>


</head>

<body <?php echo $_smarty_tpl->tpl_vars['body_onload']->value;?>
>

<h1 class="title"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->main_descr, ENT_QUOTES, 'UTF-8', true);?>
</h1>
<?php if ($_smarty_tpl->tpl_vars['gui']->value->user_feedback!=''){?>
  <div>
    <p class="info"><?php echo $_smarty_tpl->tpl_vars['gui']->value->user_feedback;?>
</p>
  </div>
<?php }?>

<div class="workBack">
<?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->testplan_create&&$_smarty_tpl->tpl_vars['gui']->value->tproject_id>0&&count($_smarty_tpl->tpl_vars['gui']->value->tplans)>$_smarty_tpl->tpl_vars['tlCfg']->value->gui->planView->itemQtyForTopButton){?>
   <div class="groupBtn">
     <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['createAction']->value;?>
" name="topCreateForm">
       <input type="submit" name="create_testplan_top" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_testplan_create'];?>
" />
     </form>
   </div>
<?php }?>

<div id="testplan_management_list">
<?php if ($_smarty_tpl->tpl_vars['gui']->value->tproject_id<=0){?>
  <?php echo $_smarty_tpl->tpl_vars['labels']->value['error_no_testprojects_present'];?>

<?php }elseif($_smarty_tpl->tpl_vars['gui']->value->tplans==''){?>
  <?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_txt_empty_list'];?>

<?php }else{ ?>
  <form method="post" id="testPlanView" name="testPlanView" action="<?php echo $_smarty_tpl->tpl_vars['managerURL']->value;?>
">
    <input type="hidden" name="do_action" id="do_action" value="">
    <input type="hidden" name="tplan_id" id="tplan_id" value="">

  <table id='item_view'class="simple_tableruler sortable">
    <thead>
    <tr>
      <th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_api_info'];?>
<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_th_name'];?>
</th>       
      <th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_th_notes'];?>
</th>
      <th title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testcase_number_help'];?>
"><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['testcase_qty'];?>
</th>
      <th title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['build_number_help'];?>
"><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['build_qty'];?>
</th>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->drawPlatformQtyColumn){?>
        <th title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['platform_number_help'];?>
"><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['platform_qty'];?>
</th>
      <?php }?> 
      <th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_th_active'];?>
</th>
      <th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
</th>
      <th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
">&nbsp;</th>
    </tr>
    </thead>
    <tbody>
    <?php  $_smarty_tpl->tpl_vars['testplan'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['testplan']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tplans; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['testplan']->key => $_smarty_tpl->tpl_vars['testplan']->value){
$_smarty_tpl->tpl_vars['testplan']->_loop = true;
?>
    <tr>
      <td><a href="<?php echo $_smarty_tpl->tpl_vars['editAction']->value;?>
<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
"> 
             <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testplan']->value['name'], ENT_QUOTES, 'UTF-8', true);?>

             <span class="api_info" style='display:none'><?php echo smarty_modifier_replace($_smarty_tpl->tpl_vars['tlCfg']->value->api->id_format,"%s",$_smarty_tpl->tpl_vars['testplan']->value['id']);?>
</span>
           
             <?php if ($_smarty_tpl->tpl_vars['gsmarty_gui']->value->show_icon_edit){?>
                 <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_alt_edit_tp'];?>
"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_alt_edit_tp'];?>
" 
                      src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['edit'];?>
"/>
             <?php }?>  
          </a>
      </td>
	  <td><?php if ($_smarty_tpl->tpl_vars['gui']->value->editorType=='none'){?><?php echo nl2br($_smarty_tpl->tpl_vars['testplan']->value['notes']);?>
<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['testplan']->value['notes'];?>
<?php }?></td>
      <td align="right" style="width:8%;">
        <?php echo $_smarty_tpl->tpl_vars['testplan']->value['tcase_qty'];?>

      </td>
      <td align="right" style="width:6%;">
        <?php echo $_smarty_tpl->tpl_vars['testplan']->value['build_qty'];?>

      </td>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->drawPlatformQtyColumn){?>
        <td align="right" style="width:10%;">
          <?php echo $_smarty_tpl->tpl_vars['testplan']->value['platform_qty'];?>

        </td>
      <?php }?> 

      <td class="clickable_icon">
        <?php if ($_smarty_tpl->tpl_vars['testplan']->value['active']==1){?> 
            <input type="image" style="border:none" 
                   title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['active_click_to_change'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['active_click_to_change'];?>
" 
                   onClick = "do_action.value='setInactive';tplan_id.value=<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
;"
                   src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['on'];?>
"/>
          <?php }else{ ?>
            <input type="image" style="border:none" 
                 title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['inactive_click_to_change'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['inactive_click_to_change'];?>
" 
                 onClick = "do_action.value='setActive';tplan_id.value=<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
;"
                 src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['off'];?>
"/>
          <?php }?>
      </td>
      <td class="clickable_icon">
        <?php if ($_smarty_tpl->tpl_vars['testplan']->value['is_public']==1){?> 
            <img style="border:none" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['checked'];?>
"/>
          <?php }else{ ?>
            &nbsp;        
          <?php }?>
      </td>
      <td style="width:8%;">
          <img style="border:none;cursor: pointer;" 
               alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_alt_delete_tp'];?>
"
             title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_alt_delete_tp'];?>
" 
             onclick="delete_confirmation(<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
,'<?php echo htmlspecialchars(strtr($_smarty_tpl->tpl_vars['testplan']->value['name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" )), ENT_QUOTES, 'UTF-8', true);?>
',
                                          '<?php echo $_smarty_tpl->tpl_vars['del_msgbox_title']->value;?>
','<?php echo $_smarty_tpl->tpl_vars['warning_msg']->value;?>
');"
             src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['delete'];?>
"/>
          <a href="<?php echo $_smarty_tpl->tpl_vars['exportAction']->value;?>
<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
"> 
          <img style="border:none;cursor: pointer;" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['export_testplan_links'];?>
" 
               title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['export_testplan_links'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['export'];?>
"/>
          </a>     
          <a href="<?php echo $_smarty_tpl->tpl_vars['importAction']->value;?>
<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
"> 
          <img style="border:none;cursor: pointer;" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['import_testplan_links'];?>
" 
               title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['import_testplan_links'];?>
"  src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['import'];?>
"/>
          </a>     

          <?php if ($_smarty_tpl->tpl_vars['testplan']->value['rights']['testplan_user_role_assignment']){?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['assignRolesAction']->value;?>
<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
"> 
            <img style="border:none;cursor: pointer;" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['assign_roles'];?>
" 
                 title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['assign_roles'];?>
"  src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['user'];?>
"/>
            </a>     
          <?php }?>
          <a href="<?php echo $_smarty_tpl->tpl_vars['gotoExecuteAction']->value;?>
<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
"> 
          <img style="border:none;cursor: pointer;" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['execution'];?>
" 
               title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['execution'];?>
"  src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['execution'];?>
"/>
          </a>     
      </td>
    </tr>
    <?php } ?>
    </tbody>
  </table>
</form>

<?php }?>
</div>

 <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->testplan_create&&$_smarty_tpl->tpl_vars['gui']->value->tproject_id>0){?>
 <div class="groupBtn">
    <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['createAction']->value;?>
" name="bottomCreateForm">
      <input type="submit" name="create_testplan" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_testplan_create'];?>
" />
    </form>
  </div>
 <?php }?>
</div>

</body>
</html><?php }} ?>