<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:32
         compiled from "/development/release/latest/gui/templates/usermanagement/usersAssign.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5948910415ad1b0acf0c644-70112646%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4e5d1463f077ced56b7d951026b5876c0435e8c8' => 
    array (
      0 => '/development/release/latest/gui/templates/usermanagement/usersAssign.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5948910415ad1b0acf0c644-70112646',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tlCfg' => 0,
    'll' => 0,
    'gui' => 0,
    'result' => 0,
    'umgmt' => 0,
    'labels' => 0,
    'styleLH' => 0,
    'f' => 0,
    'role_id' => 0,
    'role' => 0,
    'tlImages' => 0,
    'my_feature_name' => 0,
    'user' => 0,
    'uID' => 0,
    'effective_role_id' => 0,
    'ikx' => 0,
    'user_row_class' => 0,
    'globalRoleName' => 0,
    'applySelected' => 0,
    'removeRole' => 0,
    'inherited_role_name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0ad33bc87_04827109',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0ad33bc87_04827109')) {function content_5ad1b0ad33bc87_04827109($_smarty_tpl) {?><?php if (!is_callable('smarty_function_cycle')) include '/development/release/latest/third_party/smarty3/libs/plugins/function.cycle.php';
?>
<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'TestProject,TestPlan,btn_change,title_user_mgmt,set_roles_to,show_only_authorized_users,
             warn_demo,User,btn_upd_user_data,btn_do,title_assign_roles'),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('jsValidate'=>"yes",'openHead'=>"yes",'enableTableSorting'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_ext_js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('css_only'=>1), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("bootstrap.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script language="JavaScript" type="text/javascript">
/*
Set value for a group of combo (have same prefix).
MUST TO BE PLACED IN COMMON LIBRARY
*/
function set_combo_group(container_id,combo_id_prefix,value_to_assign)
{
  var container=document.getElementById(container_id);
	var all_comboboxes = container.getElementsByTagName('select');
	var input_element;
	var idx=0;

	for(idx = 0; idx < all_comboboxes.length; idx++)
	{
	  input_element=all_comboboxes[idx];
		if( input_element.type == "select-one" && 
		    input_element.id.indexOf(combo_id_prefix)==0 &&
		   !input_element.disabled)
		{
       input_element.value=value_to_assign;
		}	
	}
}
</script>

<script type="text/javascript">
function toggleRowByClass(oid,className,displayCheckOn,displayCheckOff,displayValue)
{
  var trTags = document.getElementsByTagName("tr");
  var cbox = document.getElementById(oid);
  
  for( idx=0; idx < trTags.length; idx++ ) 
  {
    if( trTags[idx].className == className ) 
    {
      if( displayValue == undefined )
      {
        if( cbox.checked )
        {
          trTags[idx].style.display = displayCheckOn;
        }
        else
        {
          trTags[idx].style.display = displayCheckOff;
        }
      } 
      else
      {
        trTags[idx].style.display = displayValue;
      }
    }
  }

}
</script>

<?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->gui->usersAssign->pagination->enabled){?>
  <?php $_smarty_tpl->tpl_vars['ll'] = new Smarty_variable($_smarty_tpl->tpl_vars['tlCfg']->value->gui->usersAssign->pagination->length, null, 0);?>
  <?php echo $_smarty_tpl->getSubTemplate ("DataTables.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('DataTablesOID'=>"item_view",'DataTableslengthMenu'=>$_smarty_tpl->tpl_vars['ll']->value), 0);?>

<?php }?>

</head>
<body>

<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['gui']->value->main_title;?>
</h1>
<?php $_smarty_tpl->tpl_vars['umgmt'] = new Smarty_variable("lib/usermanagement", null, 0);?>
<?php $_smarty_tpl->tpl_vars['my_feature_name'] = new Smarty_variable('', null, 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("usermanagement/menu.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="workBack">

<?php echo $_smarty_tpl->getSubTemplate ("inc_update.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('result'=>$_smarty_tpl->tpl_vars['result']->value,'item'=>((string)$_smarty_tpl->tpl_vars['gui']->value)."->featureType",'action'=>((string)$_smarty_tpl->tpl_vars['action']->value),'user_feedback'=>$_smarty_tpl->tpl_vars['gui']->value->user_feedback), 0);?>




<?php if ($_smarty_tpl->tpl_vars['gui']->value->features!=''){?>
<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['umgmt']->value;?>
/usersAssign.php"
	<?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->demoMode){?>
		onsubmit="alert('<?php echo $_smarty_tpl->tpl_vars['labels']->value['warn_demo'];?>
'); return false;"
	<?php }?>>
	<input type="hidden" name="featureID" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->featureID;?>
" />
	<input type="hidden" name="featureType" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->featureType;?>
" />

  <?php $_smarty_tpl->tpl_vars['styleLH'] = new Smarty_variable("padding: 0px 30px 10px 5px;", null, 0);?>
  <div class="panel panel-default" style="background-color: #EAEAED;">
    <div class="panel-body">
		<table style="border:0;">
    	<?php if ($_smarty_tpl->tpl_vars['gui']->value->featureType=='testproject'){?>
    		<tr>
          <td class="labelHolder" style="<?php echo $_smarty_tpl->tpl_vars['styleLH']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['TestProject'];?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->accessTypeImg;?>
</td>
          <td>&nbsp;</td>
    	<?php }else{ ?>
    		<tr>
          <td class="labelHolder" style="<?php echo $_smarty_tpl->tpl_vars['styleLH']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['TestProject'];?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->tprojectAccessTypeImg;?>
</td>
          <td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->tproject_name, ENT_QUOTES, 'UTF-8', true);?>
</td>
        </tr>
    		<tr>
				  <td class="labelHolder" style="<?php echo $_smarty_tpl->tpl_vars['styleLH']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['TestPlan'];?>
<?php echo $_smarty_tpl->tpl_vars['gui']->value->accessTypeImg;?>

          </td>
    	<?php }?>

		    	<td>
            <select id="featureSel" onchange="changeFeature('<?php echo $_smarty_tpl->tpl_vars['gui']->value->featureType;?>
')">
		    	   <?php  $_smarty_tpl->tpl_vars['f'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['f']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->features; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['f']->key => $_smarty_tpl->tpl_vars['f']->value){
$_smarty_tpl->tpl_vars['f']->_loop = true;
?>
		    	     <option value="<?php echo $_smarty_tpl->tpl_vars['f']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['gui']->value->featureID==$_smarty_tpl->tpl_vars['f']->value['id']){?> selected="selected" <?php }?>>
		    	     <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['f']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</option>
		    	     <?php if ($_smarty_tpl->tpl_vars['gui']->value->featureID==$_smarty_tpl->tpl_vars['f']->value['id']){?>
		    	        <?php $_smarty_tpl->tpl_vars['my_feature_name'] = new Smarty_variable($_smarty_tpl->tpl_vars['f']->value['name'], null, 0);?>
		    	     <?php }?>
		    	   <?php } ?>
		    	   </select>
		    	</td>
			<td>
          
		  </td>
			</tr>
   		<tr>
   		<td class="labelHolder" style="<?php echo $_smarty_tpl->tpl_vars['styleLH']->value;?>
""><?php echo $_smarty_tpl->tpl_vars['labels']->value['set_roles_to'];?>
</td><?php if ($_smarty_tpl->tpl_vars['gui']->value->featureType=='testproject'){?> <td>&nbsp;</td> <?php }?>
      <td>
        <select name="allUsersRole" id="allUsersRole">
		      <?php  $_smarty_tpl->tpl_vars['role'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['role']->_loop = false;
 $_smarty_tpl->tpl_vars['role_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->optRights; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['role']->key => $_smarty_tpl->tpl_vars['role']->value){
$_smarty_tpl->tpl_vars['role']->_loop = true;
 $_smarty_tpl->tpl_vars['role_id']->value = $_smarty_tpl->tpl_vars['role']->key;
?>
		        <option value="<?php echo $_smarty_tpl->tpl_vars['role_id']->value;?>
">
            <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['role']->value->getDisplayName(), ENT_QUOTES, 'UTF-8', true);?>

		        </option>
		      <?php } ?>
			  </select>
      </td>
      <td>
          &nbsp;
					<input type="button" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_do'];?>
" 
					       onclick="javascript:set_combo_group('usersRoleTable','userRole_',
					                                           document.getElementById('allUsersRole').value);"/>
		  </td>
			</tr>

		</table>
    </div>
    </div>

    <div id="usersRoleTable">
	    <table class="common table table-bordered sortable" width="100%" id="item_view">
    	<tr>
    		<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['User'];?>
</th>
    		<?php $_smarty_tpl->tpl_vars["featureVerbose"] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->featureType, null, 0);?>
    		<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo lang_get_smarty(array('s'=>"th_roles_".((string)$_smarty_tpl->tpl_vars['featureVerbose']->value)),$_smarty_tpl);?>
 (<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['my_feature_name']->value, ENT_QUOTES, 'UTF-8', true);?>
)</th>
    	</tr>
    	<?php  $_smarty_tpl->tpl_vars['user'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['user']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->users; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['user']->key => $_smarty_tpl->tpl_vars['user']->value){
$_smarty_tpl->tpl_vars['user']->_loop = true;
?>
    	    <?php $_smarty_tpl->tpl_vars['globalRoleName'] = new Smarty_variable($_smarty_tpl->tpl_vars['user']->value->globalRole->name, null, 0);?>
    			<?php $_smarty_tpl->tpl_vars['uID'] = new Smarty_variable($_smarty_tpl->tpl_vars['user']->value->dbID, null, 0);?>


          
          <?php $_smarty_tpl->tpl_vars['effective_role_id'] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->userFeatureRoles[$_smarty_tpl->tpl_vars['uID']->value]['effective_role_id'], null, 0);?>
          <?php if ($_smarty_tpl->tpl_vars['gui']->value->userFeatureRoles[$_smarty_tpl->tpl_vars['uID']->value]['is_inherited']==1){?>
            <?php $_smarty_tpl->tpl_vars['ikx'] = new Smarty_variable($_smarty_tpl->tpl_vars['effective_role_id']->value, null, 0);?>
          <?php }else{ ?>
            <?php $_smarty_tpl->tpl_vars['ikx'] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->userFeatureRoles[$_smarty_tpl->tpl_vars['uID']->value]['uplayer_role_id'], null, 0);?>
          <?php }?>
          <?php $_smarty_tpl->tpl_vars['inherited_role_name'] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->optRights[$_smarty_tpl->tpl_vars['ikx']->value]->name, null, 0);?>

          <?php $_smarty_tpl->tpl_vars['user_row_class'] = new Smarty_variable('', null, 0);?>
          <?php if ($_smarty_tpl->tpl_vars['effective_role_id']->value==@constant('TL_ROLES_NO_RIGHTS')){?>
            <?php $_smarty_tpl->tpl_vars['user_row_class'] = new Smarty_variable('class="not_authorized_user"', null, 0);?>
          <?php }?>

    	<tr <?php echo $_smarty_tpl->tpl_vars['user_row_class']->value;?>
 bgcolor="<?php echo smarty_function_cycle(array('values'=>"#eeeeee,#d0d0d0"),$_smarty_tpl);?>
">
    		<td <?php if ($_smarty_tpl->tpl_vars['gui']->value->role_colour!=''&&$_smarty_tpl->tpl_vars['gui']->value->role_colour[$_smarty_tpl->tpl_vars['globalRoleName']->value]!=''){?>  		
    		      style="background-color: <?php echo $_smarty_tpl->tpl_vars['gui']->value->role_colour[$_smarty_tpl->tpl_vars['globalRoleName']->value];?>
;" <?php }?>>
    		    <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user']->value->login, ENT_QUOTES, 'UTF-8', true);?>
 (<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user']->value->firstName, ENT_QUOTES, 'UTF-8', true);?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user']->value->lastName, ENT_QUOTES, 'UTF-8', true);?>
) </td>
    		<td>
          <select name="userRole[<?php echo $_smarty_tpl->tpl_vars['uID']->value;?>
]" id="userRole_<?php echo $_smarty_tpl->tpl_vars['uID']->value;?>
"
            <?php if ($_smarty_tpl->tpl_vars['user']->value->globalRole->dbID==@constant('TL_ROLES_ADMIN')){?>
             disabled="disabled"
            <?php }?>
          >
		      <?php  $_smarty_tpl->tpl_vars['role'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['role']->_loop = false;
 $_smarty_tpl->tpl_vars['role_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->optRights; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['role']->key => $_smarty_tpl->tpl_vars['role']->value){
$_smarty_tpl->tpl_vars['role']->_loop = true;
 $_smarty_tpl->tpl_vars['role_id']->value = $_smarty_tpl->tpl_vars['role']->key;
?>
            
            <?php $_smarty_tpl->tpl_vars['applySelected'] = new Smarty_variable('', null, 0);?>
            <?php if (($_smarty_tpl->tpl_vars['gui']->value->userFeatureRoles[$_smarty_tpl->tpl_vars['uID']->value]['effective_role_id']==$_smarty_tpl->tpl_vars['role_id']->value&&$_smarty_tpl->tpl_vars['gui']->value->userFeatureRoles[$_smarty_tpl->tpl_vars['uID']->value]['is_inherited']==0)||($_smarty_tpl->tpl_vars['role_id']->value==@constant('TL_ROLES_INHERITED')&&$_smarty_tpl->tpl_vars['gui']->value->userFeatureRoles[$_smarty_tpl->tpl_vars['uID']->value]['is_inherited']==1)){?>
                <?php $_smarty_tpl->tpl_vars['applySelected'] = new Smarty_variable(' selected="selected" ', null, 0);?> 
            <?php }?>

            /* For system consistency we need to remove admin role from selection */
            <?php $_smarty_tpl->tpl_vars['removeRole'] = new Smarty_variable(0, null, 0);?>
            <?php if ($_smarty_tpl->tpl_vars['role_id']->value==@constant('TL_ROLES_ADMIN')&&$_smarty_tpl->tpl_vars['applySelected']->value==''){?>
                <?php $_smarty_tpl->tpl_vars['removeRole'] = new Smarty_variable(1, null, 0);?>
            <?php }?>             
  
            <?php if (!$_smarty_tpl->tpl_vars['removeRole']->value){?>
              <option value="<?php echo $_smarty_tpl->tpl_vars['role_id']->value;?>
" <?php echo $_smarty_tpl->tpl_vars['applySelected']->value;?>
>
                  <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['role']->value->getDisplayName(), ENT_QUOTES, 'UTF-8', true);?>

                  <?php if ($_smarty_tpl->tpl_vars['role_id']->value==@constant('TL_ROLES_INHERITED')){?>
                    <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['inherited_role_name']->value, ENT_QUOTES, 'UTF-8', true);?>
 
                  <?php }?>
  		        </option>
            <?php }?>

		      <?php } ?>
			</select>
          <?php if ($_smarty_tpl->tpl_vars['user']->value->globalRole->dbID==@constant('TL_ROLES_ADMIN')){?>
            <?php echo $_smarty_tpl->tpl_vars['gui']->value->hintImg;?>
 
          <?php }?>
			</td>
    	</tr>
    	<?php } ?>
    	</table>
   </div> 	
   	
   	
   	<div class="groupBtn">	
    	<?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->demoMode){?>
			<?php echo $_smarty_tpl->tpl_vars['labels']->value['warn_demo'];?>

		<?php }else{ ?>	
    		<input type="submit" name="do_update" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_upd_user_data'];?>
" />
		<?php }?>
	</div>
  </form>
<?php }?> 
</div>
</body>
</html>
<?php }} ?>