<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:12
         compiled from "/development/release/latest/gui/templates/plan/planEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2283583995ad1b0980406d6-82590506%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f627363dca26789b8f32852aec70b21c89b90028' => 
    array (
      0 => '/development/release/latest/gui/templates/plan/planEdit.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2283583995ad1b0980406d6-82590506',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'gui' => 0,
    'labels' => 0,
    'cfg_section' => 0,
    'loadOnCancelURL' => 0,
    'form_action' => 0,
    'testplan' => 0,
    'planID' => 0,
    'downloadOnly' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0982c1171_99371574',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0982c1171_99371574')) {function content_5ad1b0982c1171_99371574($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>"warning,warning_empty_tp_name,testplan_title_edit,public,api_key,
             testplan_th_name,testplan_th_notes,testplan_question_create_tp_from,
             opt_no,testplan_th_active,btn_testplan_create,btn_upd,cancel,
             show_event_history,testplan_txt_notes"),$_smarty_tpl);?>




<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes",'jsValidate'=>"yes",'editorType'=>$_smarty_tpl->tpl_vars['gui']->value->editorType), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<script type="text/javascript">
var alert_box_title = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var warning_empty_tp_name = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_empty_tp_name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";

function validateForm(f)
{
  var cf_designTime = document.getElementById('custom_field_container');
  if (isWhitespace(f.testplan_name.value))
  {
      alert_message(alert_box_title,warning_empty_tp_name);
      selectField(f, 'testplan_name');
      return false;
  }
  
  /* Validation of a limited type of custom fields */
  if (cf_designTime)
  {
    var cfields_container = cf_designTime.getElementsByTagName('input');
    var cfieldsChecks = validateCustomFields(cfields_container);
    if(!cfieldsChecks.status_ok)
    {
        var warning_msg = cfMessages[cfieldsChecks.msg_id];
        alert_message(alert_box_title,warning_msg.replace(/%s/, cfieldsChecks.cfield_label));
        return false;
    }
  
    /* Text area needs a special access */
    cfields_container = cf_designTime.getElementsByTagName('textarea');
    cfieldsChecks = validateCustomFields(cfields_container);
    if(!cfieldsChecks.status_ok)
    {
        var warning_msg = cfMessages[cfieldsChecks.msg_id];
        alert_message(alert_box_title,warning_msg.replace(/%s/, cfieldsChecks.cfield_label));
        return false;
    }
  }
  return true;
}

/**
 * manage_copy_ctrls
 *
 */
function manage_copy_ctrls(container_id,display_control_value,hide_value)
{
 o_container=document.getElementById(container_id);

 if( display_control_value == hide_value )
 {
   o_container.style.display='none';
 }
 else
 {
    o_container.style.display='';
 }
}

/**
 * Be Carefull this TRUST on existence of $gui->delAttachmentURL
 */
function jsCallDeleteFile(btn, text, o_id)
{ 
  var my_action='';
  if( btn == 'yes' )
  {
    my_action='<?php echo $_smarty_tpl->tpl_vars['gui']->value->delAttachmentURL;?>
'+o_id;
    window.location=my_action;
  }
}        
</script>

</head>

<body>
<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>
<?php $_smarty_tpl->tpl_vars['planID'] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->tplan_id, null, 0);?>
<?php if (!isset($_smarty_tpl->tpl_vars['loadOnCancelURL']->value)){?>
  <?php $_smarty_tpl->tpl_vars['loadOnCancelURL'] = new Smarty_variable('', null, 0);?>
<?php }?>

<h1 class="title"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->main_descr, ENT_QUOTES, 'UTF-8', true);?>
</h1>

<div class="workBack">
<?php echo $_smarty_tpl->getSubTemplate ("inc_update.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('user_feedback'=>$_smarty_tpl->tpl_vars['gui']->value->user_feedback), 0);?>

  <?php $_smarty_tpl->tpl_vars['form_action'] = new Smarty_variable('create', null, 0);?>
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->tplan_id!=0){?>
    <h2>
    <?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_title_edit'];?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->testplan_name, ENT_QUOTES, 'UTF-8', true);?>

    <?php $_smarty_tpl->tpl_vars['form_action'] = new Smarty_variable('update', null, 0);?>
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->mgt_view_events=="yes"){?>
      <img style="margin-left:5px;" class="clickable" src="<?php echo @constant('TL_THEME_IMG_DIR');?>
/question.gif" 
           onclick="showEventHistoryFor('<?php echo $_smarty_tpl->tpl_vars['gui']->value->tplan_id;?>
','testplans')" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_event_history'];?>
" 
           title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_event_history'];?>
"/>
    <?php }?>
    </h2>
  <?php }?>

  <form method="post" name="testplan_mgmt" id="testplan_mgmt"
        action="lib/plan/planEdit.php?action=<?php echo $_smarty_tpl->tpl_vars['form_action']->value;?>
"
        onSubmit="javascript:return validateForm(this);">
  <input type="hidden" id="tplan_id" name="tplan_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tplan_id;?>
" />
  <table class="common" width="80%">

    <tr><th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_th_name'];?>
</th>
      <td><input type="text" name="testplan_name"
                 size="<?php echo $_smarty_tpl->getConfigVariable('TESTPLAN_NAME_SIZE');?>
"
                 maxlength="<?php echo $_smarty_tpl->getConfigVariable('TESTPLAN_NAME_MAXLEN');?>
"
                 value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->testplan_name, ENT_QUOTES, 'UTF-8', true);?>
" required />
          <?php echo $_smarty_tpl->getSubTemplate ("error_icon.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('field'=>"testplan_name"), 0);?>

      </td>
    </tr>
    <tr><th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_th_notes'];?>
</th>
      <td ><?php echo $_smarty_tpl->tpl_vars['gui']->value->notes;?>
</td>
    </tr>
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->tplan_id==0){?>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->tplans){?>
        <tr><th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_question_create_tp_from'];?>
</th>
        <td>
        <select name="copy_from_tplan_id"
                onchange="manage_copy_ctrls('copy_controls',this.value,'0')">
        <option value="0"><?php echo $_smarty_tpl->tpl_vars['labels']->value['opt_no'];?>
</option>
        <?php  $_smarty_tpl->tpl_vars['testplan'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['testplan']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tplans; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['testplan']->key => $_smarty_tpl->tpl_vars['testplan']->value){
$_smarty_tpl->tpl_vars['testplan']->_loop = true;
?>
          <option value="<?php echo $_smarty_tpl->tpl_vars['testplan']->value['id'];?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testplan']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</option>
        <?php } ?>
        </select>

            <div id="copy_controls" style="display:none;">
            <?php $_smarty_tpl->tpl_vars['this_template_dir'] = new Smarty_variable(dirname(basename($_smarty_tpl->source->filepath)), null, 0);?>
            <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['this_template_dir']->value)."/inc_controls_planEdit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

            </div>
        </td>
        </tr>
      <?php }?>
    <?php }?>
      <tr>
        <th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_th_active'];?>
</th>
          <td>
            <input type="checkbox" name="active" <?php if ($_smarty_tpl->tpl_vars['gui']->value->is_active==1){?>  checked="checked" <?php }?> />
          </td>
      </tr>
      <tr>
        <th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
</th>
          <td>
            <input type="checkbox" name="is_public" <?php if ($_smarty_tpl->tpl_vars['gui']->value->is_public==1){?> checked="checked" <?php }?> />
          </td>
      </tr>

      <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->api_key)&&$_smarty_tpl->tpl_vars['gui']->value->api_key!=''){?>
      <tr>
        <th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['api_key'];?>
</th>
        <td><?php echo $_smarty_tpl->tpl_vars['gui']->value->api_key;?>
</td>
      </tr>
      <?php }?>



    <?php if ($_smarty_tpl->tpl_vars['gui']->value->cfields!=''){?>
    <tr>
      <td  colspan="2">
     <div id="custom_field_container" class="custom_field_container">
     <?php echo $_smarty_tpl->tpl_vars['gui']->value->cfields;?>

     </div>
      </td>
    </tr>
    <?php }?>
  </table>

  <div class="groupBtn">
    <?php if ($_smarty_tpl->tpl_vars['gui']->value->tplan_id==0){?>
      <input type="hidden" name="do_action" value="do_create" />
      <input type="submit" name="do_create" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_testplan_create'];?>
"
             onclick="do_action.value='do_create'"/>
    <?php }else{ ?>

      <input type="hidden" name="do_action" value="do_update" />
      <input type="submit" name="do_update" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_upd'];?>
"
             onclick="do_action.value='do_update'"/>

    <?php }?>

    <input type="button" name="go_back" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['cancel'];?>
"
                         onclick="javascript: location.href=fRoot+'lib/plan/planView.php';" />

  </div>

  </form>
<?php if ($_smarty_tpl->tpl_vars['gui']->value->tplan_id!=0){?>
  <?php $_smarty_tpl->tpl_vars['downloadOnly'] = new Smarty_variable(true, null, 0);?>
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->grants->testplan_create=='yes'){?>
    <?php $_smarty_tpl->tpl_vars['downloadOnly'] = new Smarty_variable(false, null, 0);?>
  <?php }?>
  <?php echo $_smarty_tpl->getSubTemplate ("attachments.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('attach_id'=>$_smarty_tpl->tpl_vars['planID']->value,'attach_tableName'=>$_smarty_tpl->tpl_vars['gui']->value->attachmentTableName,'attach_attachmentInfos'=>$_smarty_tpl->tpl_vars['gui']->value->attachments[$_smarty_tpl->tpl_vars['planID']->value],'attach_downloadOnly'=>$_smarty_tpl->tpl_vars['downloadOnly']->value,'attach_loadOnCancelURL'=>$_smarty_tpl->tpl_vars['loadOnCancelURL']->value), 0);?>

<?php }?>
             
<p><?php echo $_smarty_tpl->tpl_vars['labels']->value['testplan_txt_notes'];?>
</p>

</div>


</body>
</html><?php }} ?>