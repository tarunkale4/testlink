<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:54
         compiled from "/development/release/latest/gui/templates/issuetrackers/issueTrackerView.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17248809825ad1b0868eb925-53049821%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '320fc63cd6e47c33896a6e3ac60b677537073e48' => 
    array (
      0 => '/development/release/latest/gui/templates/issuetrackers/issueTrackerView.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17248809825ad1b0868eb925-53049821',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'body_onload' => 0,
    'labels' => 0,
    'gui' => 0,
    'tlImages' => 0,
    'item_def' => 0,
    'del_msgbox_title' => 0,
    'warning_msg' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b086a89177_47237117',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b086a89177_47237117')) {function content_5ad1b086a89177_47237117($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>
<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('jsValidate'=>"yes",'openHead'=>"yes",'enableTableSorting'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>

<?php echo lang_get_smarty(array('var'=>'labels','s'=>'th_issuetracker,th_issuetracker_type,th_delete,th_description,menu_assign_kw_to_tc,title_issuetracker_mgmt,
          	 btn_create,alt_delete,th_issuetracker_env,check_bts_connection,bts_check_ok,bts_check_ko'),$_smarty_tpl);?>


<?php echo lang_get_smarty(array('s'=>'warning_delete','var'=>"warning_msg"),$_smarty_tpl);?>

<?php echo lang_get_smarty(array('s'=>'delete','var'=>"del_msgbox_title"),$_smarty_tpl);?>


<script type="text/javascript">
/* All this stuff is needed for logic contained in inc_del_onclick.tpl */
var del_action=fRoot+'lib/issuetrackers/issueTrackerEdit.php?doAction=doDelete&id=';
</script> 
</head>
<body <?php echo $_smarty_tpl->tpl_vars['body_onload']->value;?>
>
<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['labels']->value['title_issuetracker_mgmt'];?>
</h1>

<div class="workBack">
	<?php echo $_smarty_tpl->getSubTemplate ("inc_feedback.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('user_feedback'=>$_smarty_tpl->tpl_vars['gui']->value->user_feedback), 0);?>

	<?php if ($_smarty_tpl->tpl_vars['gui']->value->items!=''){?>
	<table class="simple_tableruler sortable">
		<tr>
			<th width="30%"><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['th_issuetracker'];?>
</th>
			<th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['th_issuetracker_type'];?>
</th>
			<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_issuetracker_env'];?>
</th>
			<?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage!=''){?>
				<th style="min-width:70px"><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['th_delete'];?>
</th>
			<?php }?>
		</tr>

  	<?php  $_smarty_tpl->tpl_vars['item_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['item_def']->_loop = false;
 $_smarty_tpl->tpl_vars['item_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->items; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['item_def']->key => $_smarty_tpl->tpl_vars['item_def']->value){
$_smarty_tpl->tpl_vars['item_def']->_loop = true;
 $_smarty_tpl->tpl_vars['item_id']->value = $_smarty_tpl->tpl_vars['item_def']->key;
?>
		<tr>
			<td>
				<?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage!=''){?>
					<a href="lib/issuetrackers/issueTrackerView.php?id=<?php echo $_smarty_tpl->tpl_vars['item_def']->value['id'];?>
">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['wrench'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_bts_connection'];?>
">
					</a>
          <?php if ($_smarty_tpl->tpl_vars['item_def']->value['connection_status']=="ok"){?>
					  <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['check_ok'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['bts_check_ok'];?>
">
				  <?php }elseif($_smarty_tpl->tpl_vars['item_def']->value['connection_status']=="ko"){?>
					  <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['check_ko'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['bts_check_ko'];?>
">
				  <?php }else{ ?>
				    &nbsp;
				  <?php }?>
				<?php }?>

				<?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage!=''){?>
					<a href="lib/issuetrackers/issueTrackerEdit.php?doAction=edit&amp;id=<?php echo $_smarty_tpl->tpl_vars['item_def']->value['id'];?>
">
				<?php }?>
				<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['item_def']->value['name'], ENT_QUOTES, 'UTF-8', true);?>

				<?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage!=''){?>
					</a>
				<?php }?>

			</td>
			<td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['item_def']->value['type_descr'], ENT_QUOTES, 'UTF-8', true);?>
</td>
			<td class="clickable_icon"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['item_def']->value['env_check_msg'], ENT_QUOTES, 'UTF-8', true);?>
</td>

				<td class="clickable_icon">
				<?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage!=''&&$_smarty_tpl->tpl_vars['item_def']->value['link_count']==0){?>
			  		<img style="border:none;cursor: pointer;"
			       		alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['alt_delete'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['alt_delete'];?>
"   
             		src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['delete'];?>
"			     
				     	 onclick="delete_confirmation(<?php echo $_smarty_tpl->tpl_vars['item_def']->value['id'];?>
,
				              '<?php echo htmlspecialchars(strtr($_smarty_tpl->tpl_vars['item_def']->value['name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" )), ENT_QUOTES, 'UTF-8', true);?>
',
				              '<?php echo $_smarty_tpl->tpl_vars['del_msgbox_title']->value;?>
','<?php echo $_smarty_tpl->tpl_vars['warning_msg']->value;?>
');" />
				<?php }?>
				</td>
		</tr>
		<?php } ?>
	</table>
	<?php }?>
	
	<div class="groupBtn">	
	  	<form name="item_view" id="item_view" method="post" action="lib/issuetrackers/issueTrackerEdit.php"> 
	  	  <input type="hidden" name="doAction" value="" />
	
		<?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage!=''){?>
	  		<input type="submit" id="create" name="create" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_create'];?>
" 
	  	           onclick="doAction.value='create'"/>
		<?php }?>
	  	</form>
	</div>
</div>

</body>
</html><?php }} ?>