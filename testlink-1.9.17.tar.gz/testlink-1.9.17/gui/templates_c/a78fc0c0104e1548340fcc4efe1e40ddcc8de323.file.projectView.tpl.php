<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:31
         compiled from "/development/release/latest/gui/templates/project/projectView.tpl" */ ?>
<?php /*%%SmartyHeaderCode:412803355ad1b06fc5fb56-43429438%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a78fc0c0104e1548340fcc4efe1e40ddcc8de323' => 
    array (
      0 => '/development/release/latest/gui/templates/project/projectView.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '412803355ad1b06fc5fb56-43429438',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'deleteAction' => 0,
    'tlCfg' => 0,
    'll' => 0,
    'body_onload' => 0,
    'gui' => 0,
    'searchAction' => 0,
    'labels' => 0,
    'createAction' => 0,
    'managerURL' => 0,
    'tlImages' => 0,
    'noSortableColumnClass' => 0,
    'editAction' => 0,
    'testproject' => 0,
    'gsmarty_gui' => 0,
    'del_msgbox_title' => 0,
    'warning_msg' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07001ab26_57116995',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07001ab26_57116995')) {function content_5ad1b07001ab26_57116995($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
?>

<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>


<?php $_smarty_tpl->tpl_vars['managerURL'] = new Smarty_variable("lib/project/projectEdit.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['deleteAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?doAction=doDelete&tprojectID=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['editAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?doAction=edit&amp;tprojectID=", null, 0);?>
<?php $_smarty_tpl->tpl_vars['createAction'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['managerURL']->value)."?doAction=create", null, 0);?>
<?php $_smarty_tpl->tpl_vars['searchAction'] = new Smarty_variable("lib/project/projectView.php?doAction=search", null, 0);?>


<?php echo lang_get_smarty(array('s'=>'popup_product_delete','var'=>"warning_msg"),$_smarty_tpl);?>

<?php echo lang_get_smarty(array('s'=>'delete','var'=>"del_msgbox_title"),$_smarty_tpl);?>


<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'title_testproject_management,testproject_txt_empty_list,tcase_id_prefix,
          th_name,th_notes,testproject_alt_edit,testproject_alt_active,btn_search_filter,
          th_requirement_feature,testproject_alt_delete,btn_create,public,hint_like_search_on_name,
          testproject_alt_requirement_feature,th_active,th_delete,th_id,btn_reset_filter,
          th_issuetracker,th_codetracker,th_reqmgrsystem_short,active_click_to_change,inactive_click_to_change,
          click_to_enable,click_to_disable'),$_smarty_tpl);?>



<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes",'enableTableSorting'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script type="text/javascript">
/* All this stuff is needed for logic contained in inc_del_onclick.tpl */
var del_action=fRoot+'<?php echo $_smarty_tpl->tpl_vars['deleteAction']->value;?>
';
</script>

<?php if ($_smarty_tpl->tpl_vars['tlCfg']->value->gui->projectView->pagination->enabled){?>
  <?php $_smarty_tpl->tpl_vars['ll'] = new Smarty_variable($_smarty_tpl->tpl_vars['tlCfg']->value->gui->projectView->pagination->length, null, 0);?>
  <?php echo $_smarty_tpl->getSubTemplate ("DataTables.inc.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('DataTablesOID'=>"item_view",'DataTableslengthMenu'=>$_smarty_tpl->tpl_vars['ll']->value), 0);?>

<?php }?>

</head>

<body <?php echo $_smarty_tpl->tpl_vars['body_onload']->value;?>
>

<h1 class="title"><?php echo $_smarty_tpl->tpl_vars['gui']->value->pageTitle;?>
</h1>
<div class="workBack">

<div class="groupBtn">
  <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['searchAction']->value;?>
" style="display:inline;">
    <input type="text" id="name" name="name" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->name;?>
"  
           size="<?php echo $_smarty_tpl->getConfigVariable('TESTPROJECT_NAME_SIZE');?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('TESTPROJECT_NAME_MAXLEN');?>
"
           placeholder="<?php echo $_smarty_tpl->tpl_vars['labels']->value['hint_like_search_on_name'];?>
" required/>
    <input type="submit" id="search" name="search" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_search_filter'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['hint_like_search_on_name'];?>
" />
  </form>
  <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['searchAction']->value;?>
" style="display:inline;">
    <input type="submit" name="resetFilter" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_reset_filter'];?>
" />
  </form>
  &nbsp;&nbsp;&nbsp;
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage){?>
  <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['createAction']->value;?>
" style="display:inline;">
    <input type="submit" id="create" name="create" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_create'];?>
" />
  </form>
  <?php }?>
</div>
<p>

<div id="testproject_management_list">
<?php if ($_smarty_tpl->tpl_vars['gui']->value->tprojects==''){?>
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->feedback!=''){?>
    <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->feedback, ENT_QUOTES, 'UTF-8', true);?>

  <?php }else{ ?>
    <?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_txt_empty_list'];?>

  <?php }?>
<?php }else{ ?>
  <form method="post" id="testProjectView" name="testProjectView" action="<?php echo $_smarty_tpl->tpl_vars['managerURL']->value;?>
">
    <input type="hidden" name="doAction" id="doAction" value="">
    <input type="hidden" name="tprojectID" id="tprojectID" value="">

  <table id="item_view" class="simple_tableruler sortable">
    <tr>
      <th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_api_info'];?>

      <?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['th_name'];?>
</th>
      <th class="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_notes'];?>
</th>
      <th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['tcase_id_prefix'];?>
</th>
      <th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['th_issuetracker'];?>
</th>
      <th><?php echo $_smarty_tpl->tpl_vars['tlImages']->value['sort_hint'];?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['th_codetracker'];?>
</th>
      <th claiss="<?php echo $_smarty_tpl->tpl_vars['noSortableColumnClass']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_requirement_feature'];?>
</th>
      <th class="icon_cell"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_active'];?>
</th>
      <th class="icon_cell"><?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
</th>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage=="yes"){?>
      <th class="icon_cell"><?php echo $_smarty_tpl->tpl_vars['labels']->value['th_delete'];?>
</th>
      <?php }?>
    </tr>
    <?php  $_smarty_tpl->tpl_vars['testproject'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['testproject']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->tprojects; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['testproject']->key => $_smarty_tpl->tpl_vars['testproject']->value){
$_smarty_tpl->tpl_vars['testproject']->_loop = true;
?>
    <tr>
      <td>    <a href="<?php echo $_smarty_tpl->tpl_vars['editAction']->value;?>
<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
">
             <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testproject']->value['name'], ENT_QUOTES, 'UTF-8', true);?>

             <span class="api_info" style='display:none'><?php echo smarty_modifier_replace($_smarty_tpl->tpl_vars['tlCfg']->value->api->id_format,"%s",$_smarty_tpl->tpl_vars['testproject']->value['id']);?>
</span>
             <?php if ($_smarty_tpl->tpl_vars['gsmarty_gui']->value->show_icon_edit){?>
                  <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_alt_edit'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_alt_edit'];?>
"
                       src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['edit'];?>
"/>
              <?php }?>
           </a>
      </td>
      <td>
        <?php if ($_smarty_tpl->tpl_vars['gui']->value->editorType=='none'){?><?php echo nl2br($_smarty_tpl->tpl_vars['testproject']->value['notes']);?>
<?php }else{ ?><?php echo $_smarty_tpl->tpl_vars['testproject']->value['notes'];?>
<?php }?></td>
      </td>
      <td width="7%">
        <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testproject']->value['prefix'], ENT_QUOTES, 'UTF-8', true);?>

      </td>
      
      <td width="7%">
        <?php echo $_smarty_tpl->tpl_vars['testproject']->value['itstatusImg'];?>
 &nbsp; <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testproject']->value['itname'], ENT_QUOTES, 'UTF-8', true);?>
 
      </td>
      <td width="7%">
        <?php echo $_smarty_tpl->tpl_vars['testproject']->value['ctstatusImg'];?>
 &nbsp; <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['testproject']->value['ctname'], ENT_QUOTES, 'UTF-8', true);?>
 
      </td>
      
      <td class="clickable_icon">
        <?php if ($_smarty_tpl->tpl_vars['testproject']->value['opt']->requirementsEnabled){?>
            <input type="image" style="border:none" 
                   title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['click_to_disable'];?>
"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['click_to_disable'];?>
" 
                   onClick = "doAction.value='disableRequirements';tprojectID.value=<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
;"
                   src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['on'];?>
"/>
          <?php }else{ ?>
            <input type="image" style="border:none" 
                   title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['click_to_enable'];?>
"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['click_to_enable'];?>
" 
                   onClick = "doAction.value='enableRequirements';tprojectID.value=<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
;"
                   src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['off'];?>
"/>
          <?php }?>
      </td>
      <td class="clickable_icon">
        <?php if ($_smarty_tpl->tpl_vars['testproject']->value['active']){?>
            <input type="image" style="border:none" 
                   title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['active_click_to_change'];?>
"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['active_click_to_change'];?>
" 
                   onClick = "doAction.value='setInactive';tprojectID.value=<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
;"
                   src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['on'];?>
"/>
          <?php }else{ ?>
            <input type="image" style="border:none" 
                   title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['inactive_click_to_change'];?>
"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['inactive_click_to_change'];?>
" 
                   onClick = "doAction.value='setActive';tprojectID.value=<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
;"
                   src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['off'];?>
"/>
          <?php }?>
      </td>
      <td class="clickable_icon">
        <?php if ($_smarty_tpl->tpl_vars['testproject']->value['is_public']){?>
            <img style="border:none"  title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['public'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['choiceOn'];?>
" />
          <?php }else{ ?>
            &nbsp;
          <?php }?>
      </td>
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->canManage=="yes"){?>
      <td class="clickable_icon">
          <img style="border:none;cursor: pointer;"  alt="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_alt_delete'];?>
"
               title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject_alt_delete'];?>
"
               onclick="delete_confirmation(<?php echo $_smarty_tpl->tpl_vars['testproject']->value['id'];?>
,'<?php echo htmlspecialchars(strtr($_smarty_tpl->tpl_vars['testproject']->value['name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" )), ENT_QUOTES, 'UTF-8', true);?>
',
                                          '<?php echo $_smarty_tpl->tpl_vars['del_msgbox_title']->value;?>
','<?php echo $_smarty_tpl->tpl_vars['warning_msg']->value;?>
');"
               src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['delete'];?>
"/>
      </td>
      <?php }?>
    </tr>
    <?php } ?>

  </table>
  </form>
<?php }?>
</div>

</div>

<?php if ($_smarty_tpl->tpl_vars['gui']->value->doAction=="reloadAll"){?>
  <script type="text/javascript">
  top.location = top.location;
  </script>
<?php }else{ ?>
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->doAction=="reloadNavBar"){?>
  <script type="text/javascript">
  // remove query string to avoid reload of home page,
  // instead of reload only navbar
  var href_pieces=parent.titlebar.location.href.split('?');
  parent.titlebar.location=href_pieces[0];
  </script>
  <?php }?>
<?php }?>

</body>
</html>
<?php }} ?>