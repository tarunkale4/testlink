<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:28
         compiled from "/development/release/latest/gui/templates/cfields/cfieldsTprojectAssign.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10767506085ad1b0a89e7a11-40110843%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ff6bc8f270c95b5658fffba8104a68bc62012ca' => 
    array (
      0 => '/development/release/latest/gui/templates/cfields/cfieldsTprojectAssign.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10767506085ad1b0a89e7a11-40110843',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'labels' => 0,
    'gui' => 0,
    'sqlResult' => 0,
    'action' => 0,
    'tlImages' => 0,
    'cf' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0a8cb3d48_57543389',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0a8cb3d48_57543389')) {function content_5ad1b0a8cb3d48_57543389($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
if (!is_callable('smarty_function_html_options')) include '/development/release/latest/third_party/smarty3/libs/plugins/function.html_options.php';
?>
<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('openHead'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_jsCheckboxes.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</head>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'name,label,display_order,location,cfields_active,testproject,btn_assign,
             cfields_tproject_assign,title_assigned_cfields,check_uncheck_all_checkboxes,
             available_on,type,required,
             manage_cfield,btn_unassign,btn_cfields_boolean_mgmt,btn_cfields_display_order,
             btn_cfields_display_attr,title_available_cfields,monitorable'),$_smarty_tpl);?>


<body>
<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>

<h1 class="title">
<?php echo $_smarty_tpl->tpl_vars['labels']->value['cfields_tproject_assign'];?>
<?php echo @constant('TITLE_SEP_TYPE2');?>
<?php echo $_smarty_tpl->tpl_vars['labels']->value['testproject'];?>
<?php echo @constant('TITLE_SEP');?>
<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->tproject_name, ENT_QUOTES, 'UTF-8', true);?>

</h1>

<?php echo $_smarty_tpl->getSubTemplate ("inc_update.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('result'=>$_smarty_tpl->tpl_vars['sqlResult']->value,'action'=>$_smarty_tpl->tpl_vars['action']->value,'item'=>"custom_field"), 0);?>



<?php if ($_smarty_tpl->tpl_vars['gui']->value->linkedCF!=''){?>
  <div class="workBack">
    <h2><?php echo $_smarty_tpl->tpl_vars['labels']->value['title_assigned_cfields'];?>
</h2>
    <form method="post">
      <div id="assigned_cf"> 
 	    
       <input type="hidden" name="memory_assigned_cf"  
                            id="memory_assigned_cf"  value="0" />
      <table class="simple_tableruler">
      	<tr>
      		<th align="center"  style="width: 5px;background-color:#005498;"> 
      		    <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_all'];?>
"
      		             onclick='cs_all_checkbox_in_div("assigned_cf","assigned_cfield","memory_assigned_cf");'
      		             title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_checkboxes'];?>
" />
      		</th>
      		<th width="40%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['name'];?>
</th>
      		<th width="40%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['label'];?>
</th>
      		<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['type'];?>
</th>
      		<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['available_on'];?>
</th>
      		<th width="15%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['display_order'];?>
</th>
      		<th width="15%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['location'];?>
</th>
      		<th width="5%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['cfields_active'];?>
</th>
          <th width="5%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['required'];?>
</th>
          <th width="5%"><?php echo $_smarty_tpl->tpl_vars['labels']->value['monitorable'];?>
</th>
      	</tr>
      	<?php  $_smarty_tpl->tpl_vars['cf'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cf']->_loop = false;
 $_smarty_tpl->tpl_vars['cf_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->linkedCF; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cf']->key => $_smarty_tpl->tpl_vars['cf']->value){
$_smarty_tpl->tpl_vars['cf']->_loop = true;
 $_smarty_tpl->tpl_vars['cf_id']->value = $_smarty_tpl->tpl_vars['cf']->key;
?>
      	<tr>
      		<td class="clickable_icon"><input type="checkbox" id="assigned_cfield<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
" name="checkedCF[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]" /></td>
   		   	<td class="bold"><a href="lib/cfields/cfieldsEdit.php?do_action=edit&amp;cfield_id=<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
"
   		   	                    title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['manage_cfield'];?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</a></td>
      		<td class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</td>
      		<td class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->cf_available_types[$_smarty_tpl->tpl_vars['cf']->value['type']], ENT_QUOTES, 'UTF-8', true);?>
</td>
      		<td class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->cf_allowed_nodes[$_smarty_tpl->tpl_vars['cf']->value['node_type_id']], ENT_QUOTES, 'UTF-8', true);?>
</td>


      		<td><input type="text" name="display_order[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]" 
      		           value="<?php echo $_smarty_tpl->tpl_vars['cf']->value['display_order'];?>
" 
      		           size="<?php echo $_smarty_tpl->getConfigVariable('DISPLAY_ORDER_SIZE');?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('DISPLAY_ORDER_MAXLEN');?>
" /></td>
      		           
      		<td>
      		
      		<?php if ($_smarty_tpl->tpl_vars['cf']->value['node_description']=='testcase'&&$_smarty_tpl->tpl_vars['cf']->value['enable_on_execution']==0){?>
			  	<select name="location[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]">
			  	  <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->locations,'selected'=>$_smarty_tpl->tpl_vars['cf']->value['location']),$_smarty_tpl);?>

			  	</select>
      		<?php }else{ ?>
      		&nbsp;
      		<?php }?>
      		</td>

      		<td><input type="checkbox" name="active_cfield[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]" 
      		                           <?php if ($_smarty_tpl->tpl_vars['cf']->value['active']==1){?> checked="checked" <?php }?> /> 
      		    <input type="hidden" name="hidden_active_cfield[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]"  value="<?php echo $_smarty_tpl->tpl_vars['cf']->value['active'];?>
" /> 
      		</td>

          <td><input type="checkbox" name="required_cfield[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]" 
                                     <?php if ($_smarty_tpl->tpl_vars['cf']->value['required']==1){?> checked="checked" <?php }?> /> 
              <input type="hidden" name="hidden_required_cfield[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]"  value="<?php echo $_smarty_tpl->tpl_vars['cf']->value['required'];?>
" /> 
          </td>

          <td><input type="checkbox" name="monitorable_cfield[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]" 
                                     <?php if ($_smarty_tpl->tpl_vars['cf']->value['monitorable']==1){?> checked="checked" <?php }?> /> 
              <input type="hidden" name="hidden_monitorable_cfield[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]"  value="<?php echo $_smarty_tpl->tpl_vars['cf']->value['monitorable'];?>
" /> 
          </td>

      	</tr>
      	<?php } ?>
      </table>
    	</div>
    	<div class="groupBtn">
        
        <input type="hidden" name="doAction" value="" />
    	  
    		<input type="submit" name="doUnassign" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_unassign'];?>
" 
    		                     onclick="doAction.value=this.name"/>
    		                     
    		<input type="submit" name="doBooleanMgmt" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_cfields_boolean_mgmt'];?>
"
    		                     onclick="doAction.value=this.name"/>

    		<input type="submit" name="doReorder" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_cfields_display_attr'];?>
" 
    		                     onclick="doAction.value=this.name"/>
    		
    	</div>
    </form>
    </div>
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['gui']->value->other_cf!=''){?>
  <div class="workBack">
    <h2><?php echo $_smarty_tpl->tpl_vars['labels']->value['title_available_cfields'];?>
</h2>
    <form method="post">
      <div id="free_cf"> 
 	    
       <input type="hidden" name="memory_free_cf"  
                            id="memory_free_cf"  value="0" />

      <table class="simple_tableruler" style="width: 50%;">
      	<tr>
      		<th align="center"  style="width: 5px;background-color:#005498;"> 
      		    <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_all'];?>
"
      		             onclick='cs_all_checkbox_in_div("free_cf","free_cfield","memory_free_cf");'
      		             title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_checkboxes'];?>
" />
      		</th>
      		<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['name'];?>
</th>
      		<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['label'];?>
</th>
      		<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['type'];?>
</th>
      		<th><?php echo $_smarty_tpl->tpl_vars['labels']->value['available_on'];?>
</th>
      	</tr>
      	<?php  $_smarty_tpl->tpl_vars['cf'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cf']->_loop = false;
 $_smarty_tpl->tpl_vars['cf_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->other_cf; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cf']->key => $_smarty_tpl->tpl_vars['cf']->value){
$_smarty_tpl->tpl_vars['cf']->_loop = true;
 $_smarty_tpl->tpl_vars['cf_id']->value = $_smarty_tpl->tpl_vars['cf']->key;
?>
      	<tr>
      		<td class="clickable_icon"> <input type="checkbox" id="free_cfield<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
" name="checkedCF[<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
]" /></td>
      		<td class="bold"><a href="lib/cfields/cfieldsEdit.php?do_action=edit&amp;cfield_id=<?php echo $_smarty_tpl->tpl_vars['cf']->value['id'];?>
"
   		   	                    title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['manage_cfield'];?>
"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</a></td>
      		<td class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf']->value['label'], ENT_QUOTES, 'UTF-8', true);?>
</td>
      		<td class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->cf_available_types[$_smarty_tpl->tpl_vars['cf']->value['type']], ENT_QUOTES, 'UTF-8', true);?>
</td>
      		<td class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->cf_allowed_nodes[$_smarty_tpl->tpl_vars['cf']->value['node_type_id']], ENT_QUOTES, 'UTF-8', true);?>
</td>
      	</tr>
      	<?php } ?>
      </table>
    	</div>
    	<div class="groupBtn">
        <input type="hidden" name="doAction" value="" />
    		<input type="submit" name="doAssign" id=this.name value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_assign'];?>
" 
    		                     onclick="doAction.value=this.name"/>
    	</div>
    </form>
    </div>
<?php }?>

</body>
</html><?php }} ?>