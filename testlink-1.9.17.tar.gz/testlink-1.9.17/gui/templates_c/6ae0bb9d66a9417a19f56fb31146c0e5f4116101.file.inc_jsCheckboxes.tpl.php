<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:28
         compiled from "/development/release/latest/gui/templates/inc_jsCheckboxes.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11102077725ad1b0a8cc9508-77134778%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ae0bb9d66a9417a19f56fb31146c0e5f4116101' => 
    array (
      0 => '/development/release/latest/gui/templates/inc_jsCheckboxes.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11102077725ad1b0a8cc9508-77134778',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'basehref' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0a8cd34b3_84940785',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0a8cd34b3_84940785')) {function content_5ad1b0a8cd34b3_84940785($_smarty_tpl) {?>


<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
gui/javascript/checkboxes.js"></script><?php }} ?>