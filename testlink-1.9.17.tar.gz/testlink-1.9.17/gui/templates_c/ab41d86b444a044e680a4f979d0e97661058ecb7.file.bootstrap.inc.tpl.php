<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:41
         compiled from "/development/release/latest/gui/templates/bootstrap.inc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2923160265ad1b079bed979-81085565%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ab41d86b444a044e680a4f979d0e97661058ecb7' => 
    array (
      0 => '/development/release/latest/gui/templates/bootstrap.inc.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2923160265ad1b079bed979-81085565',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'basehref' => 0,
    'bb' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b079c160c9_60315126',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b079c160c9_60315126')) {function content_5ad1b079c160c9_60315126($_smarty_tpl) {?><?php $_smarty_tpl->tpl_vars['bb'] = new Smarty_variable(($_smarty_tpl->tpl_vars['basehref']->value).("third_party/bootstrap/3.3.6"), null, 0);?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['bb']->value;?>
/css/bootstrap.min.css" >

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['bb']->value;?>
/css/bootstrap-theme.min.css">

<script src="<?php echo $_smarty_tpl->tpl_vars['bb']->value;?>
/js/bootstrap.min.js"></script>

<?php }} ?>