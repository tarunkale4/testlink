<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:13
         compiled from "/development/release/latest/gui/templates/inc_del_onclick.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1702031835ad1b05d985033-44679570%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b1a756714244f623d0e37a2a3a1729dcb6cf5eed' => 
    array (
      0 => '/development/release/latest/gui/templates/inc_del_onclick.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1702031835ad1b05d985033-44679570',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b05d9b4595_46902439',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b05d9b4595_46902439')) {function content_5ad1b05d9b4595_46902439($_smarty_tpl) {?>
<?php echo $_smarty_tpl->getSubTemplate ("inc_ext_js.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo lang_get_smarty(array('s'=>'Yes','var'=>"yes_b"),$_smarty_tpl);?>

<?php echo lang_get_smarty(array('s'=>'No','var'=>"no_b"),$_smarty_tpl);?>

<?php $_smarty_tpl->tpl_vars["body_onload"] = new Smarty_variable("onload=\"init_yes_no_buttons('".((string)$_smarty_tpl->tpl_vars['yes_b']->value)."','".((string)$_smarty_tpl->tpl_vars['no_b']->value)."');\"", null, 0);?>
<script type="text/javascript">
 
 
/*
  function: delete_confirmation

  args: o_id: object id, id of object on with do_action() will be done.
              is not a DOM id, but an specific application id.
              IMPORTANT: do_action() is a function defined in this file

        o_name: name of object, used to to give user feedback.

        title: pop up title
                    
        msg: can contain a wildcard (%s), that will be replaced
             with o_name.     
  
  returns: 

*/
function delete_confirmation(o_id,o_name,title,msg,pFunction)
{
	var safe_name = o_name.escapeHTML();
  var safe_title = title;
  var my_msg = msg.replace('%s',safe_name);
  if (!pFunction)
  {
		pFunction = do_action;
  }
  Ext.Msg.confirm(safe_title, my_msg,
			            function(btn, text)
			            { 
					         pFunction(btn,text,o_id);
			            });
}

/*
  function: 

  args:
  
  returns: 

*/
function init_yes_no_buttons(yes_btn,no_btn)
{
  Ext.MessageBox.buttonText.yes=yes_btn;
  Ext.MessageBox.buttonText.no=no_btn;
}
/*
  function: 

  args:
  
  returns: 

*/
function do_action(btn, text, o_id)
{ 
  // IMPORTANT:
  // del_action is defined in SMARTY TEMPLATE that is using this logic.
  //
	var my_action='';
  
  if( btn == 'yes' )
  {
    my_action=del_action+o_id;
	  window.location=my_action;
	}
}					
/*
  function: 

  args:
  
  returns: 

*/
function alert_message(title,msg)
{
  Ext.MessageBox.alert(title.escapeHTML(), msg.escapeHTML());
}

/**
 * Displays an alert message. title and message must be escaped.
 */
function alert_message_html(title,msg)
{
  Ext.MessageBox.alert(title, msg);
}

</script><?php }} ?>