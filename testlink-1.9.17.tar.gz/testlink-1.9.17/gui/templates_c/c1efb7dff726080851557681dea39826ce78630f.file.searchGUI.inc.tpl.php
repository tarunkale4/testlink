<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:41:52
         compiled from "/development/release/latest/gui/templates/search/searchGUI.inc.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6345504665ad1b0c0232a15-45113679%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1efb7dff726080851557681dea39826ce78630f' => 
    array (
      0 => '/development/release/latest/gui/templates/search/searchGUI.inc.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6345504665ad1b0c0232a15-45113679',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'basehref' => 0,
    'gui' => 0,
    'labels' => 0,
    'tlImages' => 0,
    'kw_id' => 0,
    'cf_id' => 0,
    'cf' => 0,
    'gsmarty_datepicker_format' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b0c05aa4c3_80015240',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b0c05aa4c3_80015240')) {function content_5ad1b0c05aa4c3_80015240($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
if (!is_callable('smarty_function_html_options')) include '/development/release/latest/third_party/smarty3/libs/plugins/function.html_options.php';
?>

<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".inc.tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>

<?php echo lang_get_smarty(array('var'=>"labels",'s'=>'search_items,btn_find,logical_or,logical_and,created_by,
                          edited_by,modification_date_to,modification_date_from,
                          custom_field,custom_field_value,creation_date_to,creation_date_from,keyword,type,status,req_status,reqspec_type,testcase,testsuite,title,clear_date,show_calendar,id,
                          summary,preconditions,steps,expected_results,details,tcase_wkf_status,search_words_or,search_words_and,
                          search_words_placeholder,search_words_on_attr,search_other_attr,req_type,search_created_by_ph,check_uncheck_all_checkboxes,
                          scope,requirement,req_specification,req_document_id,id'),$_smarty_tpl);?>


<div style="margin: 1px;">
<form method="post" name="fullTextSearch" id="fullTextSearch" 
      action="<?php echo $_smarty_tpl->tpl_vars['basehref']->value;?>
lib/search/search.php">
  <input type="hidden" name="doAction" id="doAction" value="doSearch">
  <input type="hidden" name="tproject_id" id="tproject_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->tproject_id;?>
">
  <input type="hidden" name="caller" id="caller" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->caller;?>
">

  
  <input type="hidden" name="mmTestCaseCell" id="mmTestCaseCell"  value="1" />
  <input type="hidden" name="mmTestSuiteCell" id="mmTestSuiteCell"  value="1" />
  <input type="hidden" name="mmReqSpecCell" id="mmReqSpecCell"  value="1" />
  <input type="hidden" name="mmReqCell" id="mmReqCell"  value="1" />



  <table class="simple" style="width:99%">     
    <tr>
     <td style="width: 20%" colspan="5">
         <select name="and_or" id="and_or">
          <option value="or" <?php echo $_smarty_tpl->tpl_vars['gui']->value->or_selected;?>
 ><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_words_or'], ENT_QUOTES, 'UTF-8', true);?>

          </option>
          <option value="and" <?php echo $_smarty_tpl->tpl_vars['gui']->value->and_selected;?>
 ><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_words_and'], ENT_QUOTES, 'UTF-8', true);?>
</option>
         </select>
         <input style="width: 20rem" type="text" name="target" id="target" 
                value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->target, ENT_QUOTES, 'UTF-8', true);?>
" 
                placeholder="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_words_placeholder'], ENT_QUOTES, 'UTF-8', true);?>
">
     </td>
    </tr>

    <tr>
    <td style="width: 2%" colspan="5">&nbsp;&nbsp;</td> 
    </tr>

    <tr>
    <td style="width: 2%" colspan="5"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_words_on_attr'], ENT_QUOTES, 'UTF-8', true);?>
</td> 
    </tr>

    <tr>
    <td style="width: 2%"></td> 
    
    <td style="width: 30%" colspan="1" id="testCaseCell"> 
      <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_all'];?>
" 
           title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_checkboxes'];?>
"
           onclick='cs_all_checkbox_in_div("testCaseCell","tc_","mmTestCaseCell");'>
      <b><?php echo $_smarty_tpl->tpl_vars['labels']->value['testcase'];?>
</b><br>
      <input type="checkbox" name="tc_title" id="tc_title" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->tc_title){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['title'];?>
<br>
      <input type="checkbox" name="tc_summary" id="tc_summary" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->tc_summary){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['summary'];?>
<br>
      <input type="checkbox" name="tc_preconditions" id="tc_preconditions" 
             value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->tc_preconditions){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['preconditions'];?>
<br>
      <input type="checkbox" name="tc_steps" id="tc_steps" 
             value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->tc_steps){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['steps'];?>
<br>
      <input type="checkbox" name="tc_expected_results" id="tc_expected_results"
             value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->tc_expected_results){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['expected_results'];?>
<br>
      <input type="checkbox" name="tc_id" id="tc_id" 
             value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->tc_id){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['id'];?>
<br>
    </td>

    <td style="width: 30%" colspan="1" id="testSuiteCell"> 
      <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_all'];?>
" 
           title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_checkboxes'];?>
"
           onclick='cs_all_checkbox_in_div("testSuiteCell","ts_","mmTestSuiteCell");'>
      <b><?php echo $_smarty_tpl->tpl_vars['labels']->value['testsuite'];?>
</b><br>
      <input type="checkbox" name="ts_title" id="ts_title" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->ts_title){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['title'];?>
<br>
      <input type="checkbox" name="ts_summary" id="ts_summary" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->ts_summary){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['details'];?>
<br>
    </td>
    
    <td style="width: 20%" colspan="1" id="reqSpecCell"> 
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->reqEnabled){?>
      <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_all'];?>
" 
           title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_checkboxes'];?>
"
           onclick='cs_all_checkbox_in_div("reqSpecCell","rs_","mmReqSpecCell");'>
        <b><?php echo $_smarty_tpl->tpl_vars['labels']->value['req_specification'];?>
</b><br>
        <input type="checkbox" name="rs_title" id="rs_title" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->rs_title){?>checked<?php }?> ><?php echo $_smarty_tpl->tpl_vars['labels']->value['title'];?>
<br>
        <input type="checkbox" name="rs_scope" id="rs_scope" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->rs_scope){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['scope'];?>
<br>
      <?php }?>
    </td>

    <td style="width: 30%" colspan="1" id="reqCell"> 
      <?php if ($_smarty_tpl->tpl_vars['gui']->value->reqEnabled){?>
      <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['toggle_all'];?>
" 
           title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['check_uncheck_all_checkboxes'];?>
"
           onclick='cs_all_checkbox_in_div("reqCell","rq_","mmReqCell");'>
        <b><?php echo $_smarty_tpl->tpl_vars['labels']->value['requirement'];?>
</b><br>
        <input type="checkbox" name="rq_title" id="rq_title"  value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->rq_title){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['title'];?>
<br>
        <input type="checkbox" name="rq_scope" id="rq_scope"  value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->rq_scope){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['scope'];?>
<br>
        <input type="checkbox" name="rq_doc_id" id="rq_doc_id" value="1" <?php if ($_smarty_tpl->tpl_vars['gui']->value->rq_doc_id){?>checked<?php }?>><?php echo $_smarty_tpl->tpl_vars['labels']->value['req_document_id'];?>
<br>
      <?php }?>    
    </td>
    
    </tr>

    <tr>
    <td style="width: 2%" colspan="5">&nbsp;&nbsp;</td> 
    </tr>

    <tr>
    <td style="width: 2%" colspan="5"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_other_attr'], ENT_QUOTES, 'UTF-8', true);?>
</td> 
    </tr>

    <tr>
      <td>&nbsp;</td>
      <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['created_by'];?>

      <input type="text" name="created_by" id="created_by" 
                 value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->created_by, ENT_QUOTES, 'UTF-8', true);?>
"
                 size="<?php echo $_smarty_tpl->getConfigVariable('AUTHOR_SIZE');?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('TCNAME_MAXLEN');?>
"/>
      <img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['info_small'];?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_created_by_ph'], ENT_QUOTES, 'UTF-8', true);?>
">

      <br><?php echo $_smarty_tpl->tpl_vars['labels']->value['edited_by'];?>

      <input type="text" name="edited_by" id ="edited_by" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->edited_by, ENT_QUOTES, 'UTF-8', true);?>
"
                 size="<?php echo $_smarty_tpl->getConfigVariable('AUTHOR_SIZE');?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('TCNAME_MAXLEN');?>
" />
<img src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['info_small'];?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['labels']->value['search_created_by_ph'], ENT_QUOTES, 'UTF-8', true);?>
">

      </td>
   

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->filter_by['keyword']){?>
      <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['keyword'];?>

         <select name="keyword_id">
          <option value="0">&nbsp;</option>
          <?php  $_smarty_tpl->tpl_vars['kw_name'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['kw_name']->_loop = false;
 $_smarty_tpl->tpl_vars['kw_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->keywords; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['kw_name']->key => $_smarty_tpl->tpl_vars['kw_name']->value){
$_smarty_tpl->tpl_vars['kw_name']->_loop = true;
 $_smarty_tpl->tpl_vars['kw_id']->value = $_smarty_tpl->tpl_vars['kw_name']->key;
?>
            <option value="<?php echo $_smarty_tpl->tpl_vars['kw_id']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['kw_id']->value==$_smarty_tpl->tpl_vars['gui']->value->keyword_id){?> selected <?php }?>>
              <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->keywords[$_smarty_tpl->tpl_vars['kw_id']->value]['keyword'], ENT_QUOTES, 'UTF-8', true);?>

            </option>
          <?php } ?>
         </select>
      </td>
    <?php }else{ ?>
      <td>&nbsp</td>  
    <?php }?>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->filter_by['custom_fields']){?>
          <td colspan="2"><?php echo $_smarty_tpl->tpl_vars['labels']->value['custom_field'];?>

          <select name="custom_field_id">
              <option value="0">&nbsp;</option>
              <?php  $_smarty_tpl->tpl_vars['cf'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cf']->_loop = false;
 $_smarty_tpl->tpl_vars['cf_id'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cf; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cf']->key => $_smarty_tpl->tpl_vars['cf']->value){
$_smarty_tpl->tpl_vars['cf']->_loop = true;
 $_smarty_tpl->tpl_vars['cf_id']->value = $_smarty_tpl->tpl_vars['cf']->key;
?>
                <option value="<?php echo $_smarty_tpl->tpl_vars['cf_id']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['cf_id']->value==$_smarty_tpl->tpl_vars['gui']->value->custom_field_id){?> selected <?php }?>><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['cf']->value['label'], ENT_QUOTES, 'UTF-8', true);?>

                </option>
              <?php } ?>
            </select>
          <br>
          <?php echo $_smarty_tpl->tpl_vars['labels']->value['custom_field_value'];?>

            <input type="text" name="custom_field_value" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->custom_field_value;?>
"
                   size="<?php echo $_smarty_tpl->getConfigVariable('CFVALUE_SIZE');?>
" maxlength="<?php echo $_smarty_tpl->getConfigVariable('CFVALUE_MAXLEN');?>
"/>
          </td>
    <?php }?>

   </tr>
    <tr>
    <td style="width: 2%" colspan="5">&nbsp;&nbsp;</td> 
    </tr>
   
      <tr>
      <td>&nbsp;</td>      
      <td><?php echo $_smarty_tpl->tpl_vars['labels']->value['creation_date_from'];?>

        <input type="text" name="creation_date_from" id="creation_date_from" 
               value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->creation_date_from, ENT_QUOTES, 'UTF-8', true);?>
" size="<?php echo $_smarty_tpl->getConfigVariable('DATE_PICKER');?>
"
               onclick="showCal('creation_date_from-cal','creation_date_from','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" readonly />
        
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_calendar'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['calendar'];?>
"
             onclick="showCal('creation_date_from-cal','creation_date_from','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" >

        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['clear_date'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['clear'];?>
"
               onclick="javascript:var x = document.getElementById('creation_date_from'); x.value = '';" >
        <div id="creation_date_from-cal" style="position:absolute;width:240px;left:300px;z-index:1;"></div>

       <br> 
      <?php echo $_smarty_tpl->tpl_vars['labels']->value['creation_date_to'];?>

  
        <input type="text" name="creation_date_to" id="creation_date_to" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->creation_date_to, ENT_QUOTES, 'UTF-8', true);?>
" 
               size="<?php echo $_smarty_tpl->getConfigVariable('DATE_PICKER');?>
"
               onclick="showCal('creation_date_to-cal','creation_date_to','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" readonly />
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_calendar'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['calendar'];?>
"
             onclick="showCal('creation_date_to-cal','creation_date_to','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" >
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['clear_date'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['clear'];?>
"
               onclick="javascript:var x = document.getElementById('creation_date_to'); x.value = '';" >
        <div id="creation_date_to-cal" style="position:absolute;width:240px;left:300px;z-index:1;"></div>
  
      <br>
      <?php echo $_smarty_tpl->tpl_vars['labels']->value['modification_date_from'];?>

      
        <input type="text" name="modification_date_from" id="modification_date_from" 
        value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->modification_date_from, ENT_QUOTES, 'UTF-8', true);?>
" 
               size="<?php echo $_smarty_tpl->getConfigVariable('DATE_PICKER');?>
"
               onclick="showCal('modification_date_from-cal','modification_date_from','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" readonly />
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_calendar'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['calendar'];?>
"
             onclick="showCal('modification_date_from-cal','modification_date_from','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" >
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['clear_date'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['clear'];?>
"
             onclick="javascript:var x = document.getElementById('modification_date_from'); x.value = '';" >
        <div id="modification_date_from-cal" style="position:absolute;width:240px;left:300px;z-index:1;"></div>
      <br>

      <?php echo $_smarty_tpl->tpl_vars['labels']->value['modification_date_to'];?>

      
        <input type="text" name="modification_date_to" id="modification_date_to" 
        value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->modification_date_to, ENT_QUOTES, 'UTF-8', true);?>
" 
               size="<?php echo $_smarty_tpl->getConfigVariable('DATE_PICKER');?>
"
               onclick="showCal('modification_date_to-cal','modification_date_to','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" readonly />
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['show_calendar'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['calendar'];?>
"
             onclick="showCal('modification_date_to-cal','modification_date_to','<?php echo $_smarty_tpl->tpl_vars['gsmarty_datepicker_format']->value;?>
');" >
        <img title="<?php echo $_smarty_tpl->tpl_vars['labels']->value['clear_date'];?>
" src="<?php echo $_smarty_tpl->tpl_vars['tlImages']->value['clear'];?>
"
             onclick="javascript:var x = document.getElementById('modification_date_to'); x.value = '';" >
        <div id="modification_date_to-cal" style="position:absolute;width:240px;left:300px;z-index:1;"></div>
      </td>

      <td colspan="1">

      <?php echo $_smarty_tpl->tpl_vars['labels']->value['tcase_wkf_status'];?>

        <select name="tcWKFStatus" id="tcWKFStatus">
          <option value="">&nbsp;</option>
            <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->tcWKFStatusDomain,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->tcWKFStatus),$_smarty_tpl);?>

          </select>
      </td>

      <td colspan="2">
        <?php if ($_smarty_tpl->tpl_vars['gui']->value->reqEnabled){?>
          <?php echo $_smarty_tpl->tpl_vars['labels']->value['req_type'];?>

          <select name="reqType" id="reqType">
            <option value="">&nbsp;</option>
              <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->reqTypes,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->reqType),$_smarty_tpl);?>

            </select>

         <br>   
         <?php echo $_smarty_tpl->tpl_vars['labels']->value['req_status'];?>

          <select name="reqStatus">
          <option value="">&nbsp;</option>
          <?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->reqStatusDomain,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->reqStatus),$_smarty_tpl);?>

          </select>
        <?php }?>
      </td>

    </tr>

  </table>
  
  <p style="padding-left: 20px;">
    <input type="submit" name="doSearch" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_find'];?>
" />
  </p>
  <?php if ($_smarty_tpl->tpl_vars['gui']->value->forceSearch){?>
    <script type="text/javascript">document.getElementById("fullTextSearch").submit();</script>
  <?php }?>
</form>
</div><?php }} ?>