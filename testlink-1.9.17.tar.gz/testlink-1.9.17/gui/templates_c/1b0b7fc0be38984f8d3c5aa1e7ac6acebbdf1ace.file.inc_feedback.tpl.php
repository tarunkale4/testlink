<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:54
         compiled from "/development/release/latest/gui/templates/inc_feedback.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4441617675ad1b086ad87b5-04360385%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1b0b7fc0be38984f8d3c5aa1e7ac6acebbdf1ace' => 
    array (
      0 => '/development/release/latest/gui/templates/inc_feedback.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4441617675ad1b086ad87b5-04360385',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'user_feedback' => 0,
    'divClass' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b086b047f6_91218673',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b086b047f6_91218673')) {function content_5ad1b086b047f6_91218673($_smarty_tpl) {?>

<?php if ($_smarty_tpl->tpl_vars['user_feedback']->value['message']!=''){?>
    <?php if ($_smarty_tpl->tpl_vars['user_feedback']->value['type']==='ERROR'){?>
		  <?php $_smarty_tpl->tpl_vars["divClass"] = new Smarty_variable("error", null, 0);?>
  	<?php }else{ ?>
		  <?php $_smarty_tpl->tpl_vars["divClass"] = new Smarty_variable("user_feedback", null, 0);?>
    <?php }?>
    <div class="<?php echo $_smarty_tpl->tpl_vars['divClass']->value;?>
">
		<p><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['user_feedback']->value['message'], ENT_QUOTES, 'UTF-8', true);?>
</p>
	</div>
<?php }?>  
<?php }} ?>