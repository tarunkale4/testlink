<?php /* Smarty version Smarty-3.1.13, created on 2018-04-14 09:40:46
         compiled from "/development/release/latest/gui/templates/cfields/cfieldsEdit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:515360745ad1b07e3e0644-87359475%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd5c0e15ee41d6ab811de26441a86861aa2d11369' => 
    array (
      0 => '/development/release/latest/gui/templates/cfields/cfieldsEdit.tpl',
      1 => 1523689623,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '515360745ad1b07e3e0644-87359475',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cfg_section' => 0,
    'managerURL' => 0,
    'labels' => 0,
    'gui' => 0,
    'node_type' => 0,
    'cfg_def' => 0,
    'cf_type' => 0,
    'operation_descr' => 0,
    'user_feedback' => 0,
    'user_action' => 0,
    'viewAction' => 0,
    'idx' => 0,
    'display_style' => 0,
    'area_name' => 0,
    'area_cfg' => 0,
    'access_key' => 0,
    'gsmarty_option_yes_no' => 0,
    'tproject' => 0,
    'del_msgbox_title' => 0,
    'warning_msg' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5ad1b07e77b1f5_56219181',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ad1b07e77b1f5_56219181')) {function content_5ad1b07e77b1f5_56219181($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/development/release/latest/third_party/smarty3/libs/plugins/modifier.replace.php';
if (!is_callable('smarty_function_html_options')) include '/development/release/latest/third_party/smarty3/libs/plugins/function.html_options.php';
?>

<?php $_smarty_tpl->tpl_vars['cfg_section'] = new Smarty_variable(smarty_modifier_replace(basename(basename($_smarty_tpl->source->filepath)),".tpl",''), null, 0);?>
<?php  $_config = new Smarty_Internal_Config("input_dimensions.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars($_smarty_tpl->tpl_vars['cfg_section']->value, 'local'); ?>

<?php $_smarty_tpl->tpl_vars['managerURL'] = new Smarty_variable("lib/cfields/cfieldsEdit.php", null, 0);?>
<?php $_smarty_tpl->tpl_vars['viewAction'] = new Smarty_variable("lib/cfields/cfieldsView.php", null, 0);?>

<?php echo lang_get_smarty(array('s'=>'warning_delete_cf','var'=>"warning_msg"),$_smarty_tpl);?>

<?php echo lang_get_smarty(array('s'=>'delete','var'=>"del_msgbox_title"),$_smarty_tpl);?>


<?php echo lang_get_smarty(array('var'=>"labels",'s'=>"btn_ok,title_cfields_mgmt,warning_is_in_use,warning,name,label,type,possible_values,
             warning_empty_cfield_name,warning_empty_cfield_label,testproject,assigned_to_testprojects,
             enable_on_design,show_on_exec,enable_on_exec,enable_on_testplan_design,
             available_on,btn_upd,btn_delete,warning_no_type_change,enable_on,
             btn_add,btn_cancel,show_on_design,show_on_testplan_design,btn_add_and_assign_to_current,"),$_smarty_tpl);?>


<?php echo $_smarty_tpl->getSubTemplate ("inc_head.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('jsValidate'=>"yes",'openHead'=>"yes"), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("inc_del_onclick.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script type="text/javascript">
/* All this stuff is needed for logic contained in inc_del_onclick.tpl */
var del_action=fRoot+'<?php echo $_smarty_tpl->tpl_vars['managerURL']->value;?>
'+'?do_action=do_delete&cfield_id=';
</script>

<script type="text/javascript">
var alert_box_title = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var warning_empty_cfield_name = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_empty_cfield_name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";
var warning_empty_cfield_label = "<?php echo strtr($_smarty_tpl->tpl_vars['labels']->value['warning_empty_cfield_label'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" ));?>
";

// -------------------------------------------------------------------------------
// To manage hide/show combo logic, depending of node type
var js_enable_on_cfg = new Array();
var js_show_on_cfg = new Array();

// DOM Object ID (oid)
js_enable_on_cfg['oid_prefix'] = new Array();
js_enable_on_cfg['oid_prefix']['boolean_combobox'] = 'cf_enable_on_';
js_enable_on_cfg['oid_prefix']['container'] = 'container_cf_enable_on_';
js_enable_on_cfg['oid'] = new Array();
js_enable_on_cfg['oid']['combobox'] = 'cf_enable_on';
js_enable_on_cfg['oid']['container'] = 'container_cf_enable_on';


// will containg show (1 /0 ) info for every node type
js_enable_on_cfg['execution'] = new Array();
js_enable_on_cfg['design'] = new Array();
js_enable_on_cfg['testplan_design'] = new Array();  // BUGID 1650 (REQ)


// DOM Object ID (oid)
js_show_on_cfg['oid_prefix'] = new Array();
js_show_on_cfg['oid_prefix']['boolean_combobox'] = 'cf_show_on_';
js_show_on_cfg['oid_prefix']['container'] = 'container_cf_show_on_';

// will containg show (1 /0 ) info for every node type
js_show_on_cfg['execution'] = new Array();
js_show_on_cfg['design'] = new Array();
js_show_on_cfg['testplan_design'] = new Array();  // BUGID 1650 (REQ)

<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['node_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->enable_on_cfg['execution']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['node_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_enable_on_cfg['execution'][<?php echo $_smarty_tpl->tpl_vars['node_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>

<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['node_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->enable_on_cfg['design']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['node_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_enable_on_cfg['design'][<?php echo $_smarty_tpl->tpl_vars['node_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>

<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['node_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->enable_on_cfg['testplan_design']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['node_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_enable_on_cfg['testplan_design'][<?php echo $_smarty_tpl->tpl_vars['node_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>


<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['node_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->show_on_cfg['execution']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['node_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_show_on_cfg['execution'][<?php echo $_smarty_tpl->tpl_vars['node_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>

<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['node_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->show_on_cfg['design']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['node_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_show_on_cfg['design'][<?php echo $_smarty_tpl->tpl_vars['node_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>

<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['node_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->show_on_cfg['testplan_design']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['node_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_show_on_cfg['testplan_design'][<?php echo $_smarty_tpl->tpl_vars['node_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>
// -------------------------------------------------------------------------------

var js_possible_values_cfg = new Array();
<?php  $_smarty_tpl->tpl_vars['cfg_def'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['cfg_def']->_loop = false;
 $_smarty_tpl->tpl_vars['cf_type'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->possible_values_cfg; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['cfg_def']->key => $_smarty_tpl->tpl_vars['cfg_def']->value){
$_smarty_tpl->tpl_vars['cfg_def']->_loop = true;
 $_smarty_tpl->tpl_vars['cf_type']->value = $_smarty_tpl->tpl_vars['cfg_def']->key;
?>
  js_possible_values_cfg[<?php echo $_smarty_tpl->tpl_vars['cf_type']->value;?>
]=<?php echo $_smarty_tpl->tpl_vars['cfg_def']->value;?>
;
<?php } ?>


function validateForm(f)
{
  if (isWhitespace(f.cf_name.value))
  {
    alert_message(alert_box_title,warning_empty_cfield_name);
    selectField(f, 'cf_name');
    return false;
  }

  if (isWhitespace(f.cf_label.value))
  {
    alert_message(alert_box_title,warning_empty_cfield_label);
    selectField(f, 'cf_label');
    return false;
  }
  return true;
}

/*
  function: configure_cf_attr
            depending of node type, custom fields attributes
            will be set to disable, is its value is nonsense
            for node type choosen by user.

  args :
         id_nodetype: id of html input used to choose node type
                      to which apply custom field


  returns: -

*/
function configure_cf_attr(id_nodetype,enable_on_cfg,show_on_cfg)
{
  var o_nodetype=document.getElementById(id_nodetype);
  var o_enable=new Array();
  var o_enable_container=new Array();
  var o_display=new Array();
  var o_display_container=new Array();


  var oid;
  var keys2loop=new Array();
  var idx;
  var key;
  var option_item;
  var enabled_option_counter=0;
  var style_display;
  var TCASE_NODE=3;   // Sorry MAGIC NUMBER
  
  keys2loop[0]='execution';
  keys2loop[1]='design';
  keys2loop[2]='testplan_design'; 

  style_display='';
  for(idx=0;idx < keys2loop.length; idx++)
  {
    key=keys2loop[idx];
    oid='option_' + key;
    option_item = document.getElementById(oid);

    // Dev Note:
    // Only Firefox (@20100829) is able to hide/show an option present on a HTML select.
    // IE and Chrome NOT 
    // Need to understand then if is better to remove all this code
    if( enable_on_cfg[key][o_nodetype.value] == 0 )
    {
      option_item.style.display='none';
    }
    else
    {
      option_item.style.display='';
      enabled_option_counter++;
    }
  }
  
  // Set Always to Test Spec Design that is valid for TL elements
  if( enabled_option_counter == 0 )
  {
    style_display='none';
  }
  document.getElementById(enable_on_cfg['oid']['container']).style.display=style_display;
  // responsible of BUGID 4000
  // document.getElementById(enable_on_cfg['oid']['combobox']).value='design';

  // ------------------------------------------------------------
  // Display on
  // ------------------------------------------------------------

  // exception if node type = test case && enable_on == execution
  // the display on execution combo has not to be displayed.

  for(idx=0;idx < keys2loop.length; idx++)
  {
    key=keys2loop[idx];
    oid=show_on_cfg['oid_prefix']['boolean_combobox']+key;
    
    o_display[key]=document.getElementById(oid);
    if( o_display[key] != null)
    {
      oid=show_on_cfg['oid_prefix']['container']+key;
      o_display_container[key]=document.getElementById(oid);
      
      if( show_on_cfg[key][o_nodetype.value] == 0 )
      {
        o_display[key].disabled='disabled';
        o_display_container[key].style.display='none';
        o_display[key].value=0;
      }
      else
      {
				// this logic is used to HIDE 'Display On Test Execution' combo
        if( o_nodetype.value == TCASE_NODE && key == 'execution' &&
        		document.getElementById(enable_on_cfg['oid']['combobox']).value == key
        )
        {
        	o_display[key].value=1;
        	o_display[key].disabled='disabled';
        	o_display_container[key].style.display='none';
				}
				else
				{
      		o_display[key].disabled='';
      		o_display_container[key].style.display='';
      	}
      }
    }
  }
  // ------------------------------------------------------------
} // configure_cf_attr



/*
  function: cfg_possible_values_display
            depending of Custom Field type, Possible Values attribute
            will be displayed or not.

  args : cf_type: id of custom field type, choosen by user.

         id_possible_values_container : id of html container
                                        where input for possible values
                                        lives. Used to manage visibility.

  returns:

*/
function cfg_possible_values_display(cfg,id_cftype,id_possible_values_container)
{

  o_cftype=document.getElementById(id_cftype);
  o_container=document.getElementById(id_possible_values_container);

  if( cfg[o_cftype.value] == 0 )
  {
    o_container.style.display='none';
  }
  else
  {
    o_container.style.display='';
  }
}

/*
  function: initShowOnExec
            called every time value of 'cf_enable_on' is changed
            to initialize  show_on_ attribute.
 
  args:
  
  returns: 

*/
function initShowOnExec(id_master,show_on_cfg)
{
  var container_oid=show_on_cfg['oid_prefix']['container']+'execution';
  var combo_oid=show_on_cfg['oid_prefix']['boolean_combobox']+'execution';
  
  var o_container=document.getElementById(container_oid);
  var o_combo=document.getElementById(combo_oid);
  
  var o_master=document.getElementById(id_master);
  
  if( o_master.value == 'execution')
  {
    o_container.style.display='none';
    o_combo.value=1;
  }
  else
  {
    o_container.style.display='';
  }
}
</script>
</head>

<body onload="configure_cf_attr('combo_cf_node_type_id',js_enable_on_cfg,js_show_on_cfg);">

<h1 class="title">
 	<?php echo $_smarty_tpl->tpl_vars['labels']->value['title_cfields_mgmt'];?>
 
	<?php echo $_smarty_tpl->getSubTemplate ("inc_help.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('helptopic'=>"hlp_customFields",'show_help_icon'=>true), 0);?>

</h1>

<h2><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['operation_descr']->value, ENT_QUOTES, 'UTF-8', true);?>
</h2>
<?php echo $_smarty_tpl->getSubTemplate ("inc_update.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('user_feedback'=>$_smarty_tpl->tpl_vars['user_feedback']->value), 0);?>


<?php if ($_smarty_tpl->tpl_vars['gui']->value->cfield_is_used){?>
  <div class="user_feedback"><?php echo $_smarty_tpl->tpl_vars['labels']->value['warning_no_type_change'];?>
</div>
<?php }?>

<div class="workBack">

<?php if ($_smarty_tpl->tpl_vars['user_action']->value=="do_delete"){?>
  <form method="post" name="cfields_edit" action="<?php echo $_smarty_tpl->tpl_vars['viewAction']->value;?>
">
   <div class="groupBtn">
		<input type="submit" name="ok" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_ok'];?>
" />
	 </div>
  </form>

<?php }else{ ?>
<form method="post" name="cfields_edit" action="lib/cfields/cfieldsEdit.php"
      onSubmit="javascript:return validateForm(this);">
<input type="hidden" id="hidden_id" name="cfield_id" value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->cfield['id'];?>
" />
<table class="common">

	 <tr>
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['name'];?>
</th>
			<td><input type="text" name="cf_name"
			                       size="<?php echo $_smarty_tpl->getConfigVariable('CFIELD_NAME_SIZE');?>
"
			                       maxlength="<?php echo $_smarty_tpl->getConfigVariable('CFIELD_NAME_MAXLEN');?>
"
    			 value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->cfield['name'], ENT_QUOTES, 'UTF-8', true);?>
" required />
           <?php echo $_smarty_tpl->getSubTemplate ("error_icon.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('field'=>"cf_name"), 0);?>

    	</td>
		</tr>
		<tr>
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['label'];?>
</th>
			<td><input type="text" name="cf_label"
			                       size="<?php echo $_smarty_tpl->getConfigVariable('CFIELD_LABEL_SIZE');?>
"
			                       maxlength="<?php echo $_smarty_tpl->getConfigVariable('CFIELD_LABEL_MAXLEN');?>
"
			           value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['gui']->value->cfield['label'], ENT_QUOTES, 'UTF-8', true);?>
" required />
		           <?php echo $_smarty_tpl->getSubTemplate ("error_icon.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array('field'=>"cf_label"), 0);?>

    	</td>
	  </tr>
		<tr>
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['available_on'];?>
</th>
			<td>
			  <?php if ($_smarty_tpl->tpl_vars['gui']->value->cfield_is_used){?> 
			    <?php $_smarty_tpl->tpl_vars["idx"] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->cfield['node_type_id'], null, 0);?>
			    <?php echo $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->cf_allowed_nodes[$_smarty_tpl->tpl_vars['idx']->value];?>

			    <input type="hidden" id="combo_cf_node_type_id"
			           value=<?php echo $_smarty_tpl->tpl_vars['gui']->value->cfield['node_type_id'];?>
 name="cf_node_type_id" />
			  <?php }else{ ?>
  				<select onchange="configure_cf_attr('combo_cf_node_type_id',
  				                                    js_enable_on_cfg,
  				                                    js_show_on_cfg);"
  				        id="combo_cf_node_type_id"
  				        name="cf_node_type_id">
  				<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->cf_allowed_nodes,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->cfield['node_type_id']),$_smarty_tpl);?>

  				</select>
				<?php }?>
			</td>
		</tr>

		<tr>
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['type'];?>
</th>
			<td>
			  <?php if ($_smarty_tpl->tpl_vars['gui']->value->cfield_is_used){?>
			    <?php $_smarty_tpl->tpl_vars['idx'] = new Smarty_variable($_smarty_tpl->tpl_vars['gui']->value->cfield['type'], null, 0);?>
			    <?php echo $_smarty_tpl->tpl_vars['gui']->value->cfield_types[$_smarty_tpl->tpl_vars['idx']->value];?>

			    <input type="hidden" id="hidden_cf_type"
			           value=<?php echo $_smarty_tpl->tpl_vars['gui']->value->cfield['type'];?>
 name="cf_type" />
			  <?php }else{ ?>
  				<select onchange="cfg_possible_values_display(js_possible_values_cfg,
  				                                              'combo_cf_type',
  				                                              'possible_values');"
  				        id="combo_cf_type"
  				        name="cf_type">
	  			<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gui']->value->cfield_types,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->cfield['type']),$_smarty_tpl);?>

		  		</select>
		  	<?php }?>
			</td>
		</tr>

    <?php if ($_smarty_tpl->tpl_vars['gui']->value->show_possible_values){?>
      <?php $_smarty_tpl->tpl_vars['display_style'] = new Smarty_variable('', null, 0);?>
    <?php }else{ ?>
      <?php $_smarty_tpl->tpl_vars['display_style'] = new Smarty_variable("none", null, 0);?>
		<?php }?>
		<tr id="possible_values" style="display:<?php echo $_smarty_tpl->tpl_vars['display_style']->value;?>
;">
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['possible_values'];?>
</th>
			<td>
				<input type="text" id="cf_possible_values"
				                   name="cf_possible_values"
		                       size="<?php echo $_smarty_tpl->getConfigVariable('CFIELD_POSSIBLE_VALUES_SIZE');?>
"
		                       maxlength="<?php echo $_smarty_tpl->getConfigVariable('CFIELD_POSSIBLE_VALUES_MAXLEN');?>
"
				                   value="<?php echo $_smarty_tpl->tpl_vars['gui']->value->cfield['possible_values'];?>
" />
			</td>
		</tr>

   
    
		<tr	id="container_cf_enable_on">
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['enable_on'];?>
</th>
			<td>
				<select name="cf_enable_on" id="cf_enable_on"
				        onchange="initShowOnExec('cf_enable_on',js_show_on_cfg);">
        <?php  $_smarty_tpl->tpl_vars['area_cfg'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['area_cfg']->_loop = false;
 $_smarty_tpl->tpl_vars['area_name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->cf_enable_on; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['area_cfg']->key => $_smarty_tpl->tpl_vars['area_cfg']->value){
$_smarty_tpl->tpl_vars['area_cfg']->_loop = true;
 $_smarty_tpl->tpl_vars['area_name']->value = $_smarty_tpl->tpl_vars['area_cfg']->key;
?>
          <?php $_smarty_tpl->tpl_vars["access_key"] = new Smarty_variable("enable_on_".((string)$_smarty_tpl->tpl_vars['area_name']->value), null, 0);?>
				  <option value=<?php echo $_smarty_tpl->tpl_vars['area_name']->value;?>
 id="option_<?php echo $_smarty_tpl->tpl_vars['area_name']->value;?>
" 
				          <?php if ($_smarty_tpl->tpl_vars['area_cfg']->value['value']==0){?> style="display:none;" <?php }?> 
				  <?php if ($_smarty_tpl->tpl_vars['gui']->value->cfield[$_smarty_tpl->tpl_vars['access_key']->value]){?> selected="selected"	<?php }?>><?php echo $_smarty_tpl->tpl_vars['area_cfg']->value['label'];?>
</option>
				<?php } ?>
				</select>
			</td>
		</tr>


    
    
    		<tr id="container_cf_show_on_execution" <?php echo $_smarty_tpl->tpl_vars['gui']->value->cfieldCfg->cf_show_on['execution']['style'];?>
>
			<th style="background:none;"><?php echo $_smarty_tpl->tpl_vars['labels']->value['show_on_exec'];?>
</th>
			<td>
				<select id="cf_show_on_execution"  name="cf_show_on_execution">
				<?php echo smarty_function_html_options(array('options'=>$_smarty_tpl->tpl_vars['gsmarty_option_yes_no']->value,'selected'=>$_smarty_tpl->tpl_vars['gui']->value->cfield['show_on_execution']),$_smarty_tpl);?>

				</select>
			</td>
		</tr>

	</table>

  
  <?php if (isset($_smarty_tpl->tpl_vars['gui']->value->cfield_is_linked)&&$_smarty_tpl->tpl_vars['gui']->value->cfield_is_linked){?>
  <table class="common">
    <tr> <th><?php echo $_smarty_tpl->tpl_vars['labels']->value['assigned_to_testprojects'];?>
 </th>
    <?php  $_smarty_tpl->tpl_vars['tproject'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['tproject']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['gui']->value->linked_tprojects; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['tproject']->key => $_smarty_tpl->tpl_vars['tproject']->value){
$_smarty_tpl->tpl_vars['tproject']->_loop = true;
?>
      <tr> <td><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['tproject']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
</td> </tr>
    <?php } ?>
  </table>

  <?php }?>

	<div class="groupBtn">
	<input type="hidden" name="do_action" value="" />
	<?php if ($_smarty_tpl->tpl_vars['user_action']->value=='edit'||$_smarty_tpl->tpl_vars['user_action']->value=='do_update'){?>
		<input type="submit" name="do_update" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_upd'];?>
"
		       onclick="do_action.value='do_update'"/>

		
		
  		<input type="button" name="do_delete" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_delete'];?>
"
  		       onclick="delete_confirmation(<?php echo $_smarty_tpl->tpl_vars['gui']->value->cfield['id'];?>
,'<?php echo htmlspecialchars(strtr($_smarty_tpl->tpl_vars['gui']->value->cfield['name'], array("\\" => "\\\\", "'" => "\\'", "\"" => "\\\"", "\r" => "\\r", "\n" => "\\n", "</" => "<\/" )), ENT_QUOTES, 'UTF-8', true);?>
',
  		                                    '<?php echo $_smarty_tpl->tpl_vars['del_msgbox_title']->value;?>
','<?php echo $_smarty_tpl->tpl_vars['warning_msg']->value;?>
');">
    

	<?php }else{ ?>
		<input type="submit" name="do_update" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_add'];?>
"
		       onclick="do_action.value='do_add'"/>

    <input type="submit" name="do_add_and_assign" id="do_add_and_assign" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_add_and_assign_to_current'];?>
"
           onclick="do_action.value='do_add_and_assign'"/>
	<?php }?>
		<input type="button" name="cancel" value="<?php echo $_smarty_tpl->tpl_vars['labels']->value['btn_cancel'];?>
"
			onclick="javascript: location.href=fRoot+'lib/cfields/cfieldsView.php';" />

	</div>
</form>
<hr />
<?php }?>

</div>

</body>
</html><?php }} ?>